export type HouseCopy = {
  kicker: string;
  title: string;
  blurb: string;
  whyTitle: string;
  why: string;
  storyTitle: string;
  story: string;
  factoryTitle: string;
  factoryLead: string;
  factoryBody: string;
  shareLine: string;
  deliveryNote: string;
  invoiceFrom: string;
  invoicePay: string;
  invoiceNote: string;
};

export const DEFAULT_COPY: HouseCopy = {
  kicker: "Handmade in our factory · 2026",
  title: "Modern comfort.\nTimeless character.",
  blurb:
    "Leather shoes we last ourselves. Vellies, golfers, chelseas, derbies. The 45xxx is the stock number. The rand is the listed price.",
  whyTitle: "Why this pair",
  why: `The last is ours. So is the hide, the stitch, and the pair that leaves the bench. That is not a mill with a sticker.

You wear them on a Tuesday. Not to a photoshoot. Vellies that crease the right way. Golfers with crepe. Chelseas that keep their line.

Ninety-two pairs in the book, 45001–45092. WhatsApp the stock number. We confirm the pair is there. Then we send it.`,
  storyTitle: "Our shoes",
  story:
    "SABLE.CO is a leather house in South Africa. We cut and last in-house. Lead times come back to us. Quality comes back to us. If a pair is not on the bench, we say so — we do not invent stock.",
  factoryTitle: "Own factory.",
  factoryLead: "Our shoes",
  factoryBody:
    "SABLE.CO cuts and lasts in-house. That is the point. Hide quality and the last are ours.\n\nThe 2026 book is ninety-two stock numbers, 45001–45092. Confirm the pair before you promise it.",
  shareLine:
    "SABLE.CO — our shoes. Handmade leather. Stock 45001–45092. Listed price, subject to availability.",
  deliveryNote:
    "Collect if you are close. Local delivery R100. International R300. A manager can change the fee.",
  invoiceFrom: "SABLE.CO\nOur shoes\nSouth Africa",
  invoicePay: "EFT on request. Confirm the pair is available before you pay.",
  invoiceNote: "Prices as listed. Subject to availability. Handmade.",
};

export const DEFAULT_FEATURED = [1, 4, 15, 88];

export const DEFAULT_DELIVERY = {
  local: 100,
  international: 300,
};
