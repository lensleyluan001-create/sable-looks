/** 2026 Minimal Catalogue. Item N = stock 4500N. Names = type until factory stamps lock.

 * Retail and /shoes/{stock}.jpg are locked page-by-page from the PDF / Floor OS.
 * Cost: about R200 profit on the pair (cost = retail − 200). 45001 factory cost is R350.
 * Sales never see cost. Ninety-two stock numbers. Item 93 in the PDF is POA — not in this book.
 */

export type Category = "Footwear" | "Golfers" | "Wool lined" | "Kids";

export type Product = {
  sku: string;
  n: number;
  look: string;
  type: string;
  category: Category;
  price: number;
  cost: number;
  image: string;
  blurb: string;
};

export const PAIR_PROFIT = 200;

export function stockOf(n: number) {
  return String(45000 + n);
}

export function pairCost(retail: number, stock: string) {
  if (stock === "45001") return 350;
  return Math.max(0, Math.round(retail) - PAIR_PROFIT);
}

export const LOOK_PHOTO_HOST =
  "https://raw.githubusercontent.com/lensleyluan001-create/sable-looks/main";

export function shoeImage(stock: string) {
  return `${LOOK_PHOTO_HOST}/${stock}.jpg`;
}

export function housePhoto(name: string) {
  return `${LOOK_PHOTO_HOST}/${name}.jpg`;
}


/** Accept 45004, item 4, SB-26-004. */
export function parseStock(raw: string): string | null {
  const q = raw.trim();
  const five = q.match(/\b(45\d{3})\b/);
  if (five) {
    const n = Number(five[1]);
    if (n >= 45001 && n <= 45092) return String(n);
  }
  const legacy = q.match(/sb-?26-?0*(\d{1,3})/i);
  if (legacy) {
    const n = Number(legacy[1]);
    if (n >= 1 && n <= 92) return stockOf(n);
  }
  const item = q.match(/\b(?:item|sku|stock|look)\s*0*(\d{1,3})\b/i);
  if (item) {
    const n = Number(item[1]);
    if (n >= 1 && n <= 92) return stockOf(n);
  }
  return null;
}

const RAW: Array<[number, string, number, number]> = [
  [1, "Vellie", 599, 350],
  [2, "Vellie", 649, 449],
  [3, "Vellie", 599, 399],
  [4, "Golfer", 1200, 1000],
  [5, "Vellie", 699, 499],
  [6, "Vellie", 599, 399],
  [7, "Vellie", 649, 449],
  [8, "Wool-lined boot", 799, 599],
  [9, "Wool-lined boot", 799, 599],
  [10, "Wool-lined slipper", 699, 499],
  [11, "Hiking boot", 799, 599],
  [12, "Vellie", 649, 449],
  [13, "Derby", 599, 399],
  [14, "Derby", 799, 599],
  [15, "Chelsea", 1100, 900],
  [16, "Vellie", 599, 399],
  [17, "Vellie", 799, 599],
  [18, "Vellie", 699, 499],
  [19, "Vellie", 699, 499],
  [20, "Derby", 599, 399],
  [21, "Derby", 599, 399],
  [22, "Derby", 799, 599],
  [23, "Golfer", 999, 799],
  [24, "Derby", 599, 399],
  [25, "Derby", 599, 399],
  [26, "Derby", 599, 399],
  [27, "Sandal", 449, 249],
  [28, "Thong", 449, 249],
  [29, "Thong", 449, 249],
  [30, "Sandal", 449, 249],
  [31, "Derby", 649, 449],
  [32, "Zip boot", 899, 699],
  [33, "Derby", 599, 399],
  [34, "Derby", 599, 399],
  [35, "Derby", 599, 399],
  [36, "Vellie", 649, 449],
  [37, "Vellie", 649, 449],
  [38, "Vellie", 649, 449],
  [39, "Chelsea", 1100, 900],
  [40, "Chelsea", 1100, 900],
  [41, "Derby", 649, 449],
  [42, "Derby", 599, 399],
  [43, "Loafer", 699, 499],
  [44, "Vellie", 649, 449],
  [45, "Vellie", 699, 499],
  [46, "Vellie", 699, 499],
  [47, "Golfer", 850, 650],
  [48, "Vellie", 699, 499],
  [49, "Thong", 449, 249],
  [50, "Vellie", 699, 499],
  [51, "Vellie", 699, 499],
  [52, "Vellie", 699, 499],
  [53, "Vellie", 699, 499],
  [54, "Vellie", 699, 499],
  [55, "Vellie", 649, 449],
  [56, "Hiking boot", 799, 599],
  [57, "Wool-lined vellie", 799, 599],
  [58, "Vellie", 699, 499],
  [59, "Vellie", 799, 599],
  [60, "Golfer", 1100, 900],
  [61, "Hiking boot", 799, 599],
  [62, "Vellie", 699, 499],
  [63, "Golfer", 1300, 1100],
  [64, "Vellie", 699, 499],
  [65, "Combat boot", 1400, 1200],
  [66, "Combat boot", 1400, 1200],
  [67, "Combat boot", 1400, 1200],
  [68, "Combat boot", 1200, 1000],
  [69, "Chelsea", 1100, 900],
  [70, "Chelsea", 1100, 900],
  [71, "Chelsea", 1100, 900],
  [72, "Chelsea", 1100, 900],
  [73, "Chelsea", 1100, 900],
  [74, "Chelsea", 1100, 900],
  [75, "Chelsea", 1100, 900],
  [76, "Chelsea", 1100, 900],
  [77, "Chelsea", 1100, 900],
  [78, "Kids vellie", 399, 199],
  [79, "Kids derby", 399, 199],
  [80, "Hiking boot", 1400, 1200],
  [81, "Hiking boot", 899, 699],
  [82, "Hiking boot", 1400, 1200],
  [83, "Hiking boot", 1400, 1200],
  [84, "Hiking boot", 1400, 1200],
  [85, "Hiking boot", 1400, 1200],
  [86, "Hiking boot", 1400, 1200],
  [87, "Vellie", 699, 499],
  [88, "Combat boot", 1600, 1400],
  [89, "Vellie", 699, 499],
  [90, "Golfer", 1200, 1000],
  [91, "Zip boot", 799, 599],
  [92, "Vellie", 699, 499],
];

const BLURB: Record<string, string> = {
  Vellie: "The Sable everyday. Leather upper. Crepe comfort. Built for the week.",
  Golfer: "Veldskoen DNA. Crepe sole. The South African daily driver.",
  Chelsea: "Pull-on last. Clean line. Week and weekend.",
  Derby: "Closed lacing. Structured toe. Office to dinner.",
  Loafer: "Slip on. Soft leather. Nothing extra.",
  Sandal: "Open leather. Light on the foot. Summer floor.",
  Thong: "Minimal strap. Easy leather. Daily open shoe.",
  "Hiking boot": "Taller shaft. Grip sole. Built for dirt and distance.",
  "Combat boot": "Heavier hide. Stronger last. Made to last a decade.",
  "Zip boot": "Side zip. Boot height. Fast on, structured shaft.",
  "Wool-lined boot": "Wool-lined for highveld mornings. Same last, warmer core.",
  "Wool-lined slipper": "Indoor wool. Soft last. House and fire.",
  "Wool-lined vellie": "Vellie last, wool lined. Winter everyday.",
  "Kids vellie": "Small last. Same house, smaller pair.",
  "Kids derby": "Kids closed lace. Same factory, junior size.",
};

function categoryOf(type: string): Category {
  if (type === "Golfer") return "Golfers";
  if (type.startsWith("Wool-lined")) return "Wool lined";
  if (type.startsWith("Kids")) return "Kids";
  return "Footwear";
}

export const PRODUCTS: Product[] = RAW.map(([n, type, price, cost]) => {
  const sku = stockOf(n);
  return {
    sku,
    n,
    look: type,
    type,
    category: categoryOf(type),
    price,
    cost,
    image: shoeImage(sku),
    blurb: BLURB[type] ?? "Handmade leather. Our shoes.",
  };
});

export const SHOE_TYPES = [
  "Vellie",
  "Golfer",
  "Chelsea",
  "Derby",
  "Loafer",
  "Sandal",
  "Thong",
  "Hiking boot",
  "Combat boot",
  "Zip boot",
  "Wool-lined boot",
  "Wool-lined slipper",
  "Wool-lined vellie",
  "Kids vellie",
  "Kids derby",
] as const;

export const FILTERS = [
  "All",
  "Vellie",
  "Golfer",
  "Chelsea",
  "Derby",
  "Hiking boot",
  "Combat boot",
  "Kids",
  "Open",
] as const;

export type Filter = (typeof FILTERS)[number];

export function matchesFilter(p: Product, filter: Filter) {
  if (filter === "All") return true;
  if (filter === "Kids") return p.type.startsWith("Kids");
  if (filter === "Open") {
    return ["Sandal", "Thong", "Loafer", "Wool-lined slipper"].includes(p.type);
  }
  if (filter === "Vellie") {
    return p.type === "Vellie" || p.type === "Wool-lined vellie";
  }
  return p.type === filter;
}

export const CATEGORIES: Category[] = ["Footwear", "Golfers", "Wool lined", "Kids"];

export function bySku(sku: string) {
  const stock = parseStock(sku) ?? sku;
  return PRODUCTS.find((p) => p.sku === stock);
}

export const STATS = {
  count: PRODUCTS.length,
  priced: PRODUCTS.length,
  min: Math.min(...PRODUCTS.map((p) => p.price)),
  max: Math.max(...PRODUCTS.map((p) => p.price)),
  golfers: PRODUCTS.filter((p) => p.type === "Golfer").length,
  vellies: PRODUCTS.filter((p) => p.type === "Vellie" || p.type === "Wool-lined vellie").length,
  wool: PRODUCTS.filter((p) => p.category === "Wool lined").length,
};
