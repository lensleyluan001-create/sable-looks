import { useMemo } from "react";
import { PRODUCTS, parseStock, type Product } from "@/lib/catalogue";
import { notesFor, type MemoryNote } from "@/lib/memory";
import { useSable } from "@/lib/store";
import type { Role } from "@/lib/access";

export function mergeProducts(
  prices: Record<string, number | null>,
  looks: Record<string, string>,
): Product[] {
  return PRODUCTS.map((p) => ({
    ...p,
    price: Object.prototype.hasOwnProperty.call(prices, p.sku)
      ? (prices[p.sku] ?? p.price)
      : p.price,
    look: looks[p.sku] ?? p.look,
  }));
}

export function mergeNotes(
  role: Role,
  bodies: Record<string, string>,
  extra: MemoryNote[],
): MemoryNote[] {
  const base = notesFor(role).map((n) =>
    bodies[n.slug] ? { ...n, body: bodies[n.slug] } : n,
  );
  const more = extra.filter((n) => {
    if (n.minRole === "sales") return true;
    if (n.minRole === "manager") return role === "manager" || role === "admin";
    return role === "admin";
  });
  return [...base, ...more];
}

export function useLiveProducts() {
  const prices = useSable((s) => s.prices);
  const looks = useSable((s) => s.looks);
  return useMemo(() => mergeProducts(prices, looks), [prices, looks]);
}

export function useLiveNotes() {
  const role = useSable((s) => s.deskRole);
  const bodies = useSable((s) => s.noteBodies);
  const extra = useSable((s) => s.customNotes);
  return useMemo(() => mergeNotes(role, bodies, extra), [role, bodies, extra]);
}

export function useLiveFeatured() {
  const products = useLiveProducts();
  const featured = useSable((s) => s.featured);
  return useMemo(
    () =>
      featured
        .map((n) => products.find((p) => p.n === n))
        .filter((p): p is Product => Boolean(p)),
    [featured, products],
  );
}

export function liveBySku(list: Product[], sku: string) {
  const stock = parseStock(sku) ?? sku;
  return list.find((p) => p.sku === stock) ?? list.find((p) => p.sku === sku);
}
