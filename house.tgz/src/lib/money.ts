import { DEFAULT_DELIVERY } from "@/lib/copy";

export type DeliveryKind = "collect" | "local" | "international" | "custom";

export type DeliveryRates = {
  local: number;
  international: number;
};

export const DELIVERY_LABEL: Record<DeliveryKind, string> = {
  collect: "Collect",
  local: "Local delivery",
  international: "International",
  custom: "Custom fee",
};

export function deliveryFee(
  kind: DeliveryKind,
  rates: DeliveryRates = DEFAULT_DELIVERY,
  custom = 0,
) {
  if (kind === "collect") return 0;
  if (kind === "local") return rates.local;
  if (kind === "international") return rates.international;
  return Math.max(0, Math.round(custom) || 0);
}

export function lineTotal(unit: number, qty: number) {
  return Math.max(0, Math.round(unit) * Math.max(1, Math.round(qty) || 1));
}

export function invoiceTotal(unit: number, qty: number, fee: number) {
  return lineTotal(unit, qty) + Math.max(0, Math.round(fee) || 0);
}
