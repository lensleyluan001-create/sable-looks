import type { Role } from "@/lib/access";
import { atLeast } from "@/lib/access";
import { parseStock, type Product } from "@/lib/catalogue";
import type { HouseCopy } from "@/lib/copy";
import type { MemoryNote } from "@/lib/memory";
import type { Enquiry } from "@/lib/store";
import { zar } from "@/lib/utils";

export type ChatTurn = { role: "user" | "assistant"; content: string };
export type HouseDid =
  | "price"
  | "look"
  | "note"
  | "copy"
  | "featured"
  | "reset"
  | "enquiry";

export type HouseResult = { text: string; did?: HouseDid };

export type HouseCtx = {
  role: Role;
  products: Product[];
  notes: MemoryNote[];
  enquiries?: Enquiry[];
  history?: ChatTurn[];
  copy?: HouseCopy;
  featured?: number[];
  setPrice?: (sku: string, price: number | null) => void;
  clearPrice?: (sku: string) => void;
  setLook?: (sku: string, look: string) => void;
  setNoteBody?: (slug: string, body: string) => void;
  addNote?: (note: MemoryNote) => void;
  addEnquiry?: (e: {
    sku: string;
    look: string;
    size: string;
    qty: number;
    name: string;
    phone: string;
    note: string;
    delivery?: "collect" | "local" | "international" | "custom";
    deliveryFee?: number;
  }) => void;
  setCopy?: (partial: Partial<HouseCopy>) => void;
  setFeatured?: (ns: number[]) => void;
  resetOverrides?: () => void;
};

function findProducts(q: string, products: Product[]): Product[] {
  const stock = parseStock(q);
  if (stock) {
    const hit = products.find((p) => p.sku === stock);
    if (hit) return [hit];
  }
  const item = q.match(/\b(?:item|sku|stock|look)\s*0*(\d{1,3})\b/i);
  if (item) {
    const n = Number(item[1]);
    return products.filter((p) => p.n === n);
  }
  const words = q
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, " ")
    .split(/\s+/)
    .filter((w) => w.length > 2);
  if (words.length === 0) return [];
  const skip = new Set([
    "the",
    "and",
    "for",
    "with",
    "whatsapp",
    "message",
    "please",
    "what",
    "price",
    "listed",
    "item",
    "look",
    "sable",
    "quote",
    "send",
    "this",
    "that",
    "from",
    "under",
    "over",
    "stock",
    "type",
  ]);
  const keys = words.filter((w) => !skip.has(w));
  if (keys.length === 0) return [];
  const scored = products
    .map((p) => {
      const hay = `${p.look} ${p.sku} ${p.type} ${p.category}`.toLowerCase();
      const hits = keys.filter((w) => hay.includes(w)).length;
      return { p, hits };
    })
    .filter((x) => x.hits > 0)
    .sort((a, b) => b.hits - a.hits);
  return scored.slice(0, 8).map((x) => x.p);
}

function fromHistory(history: ChatTurn[] | undefined, products: Product[]): Product[] {
  if (!history?.length) return [];
  for (let i = history.length - 1; i >= 0; i--) {
    const hits = findProducts(history[i].content, products);
    if (hits[0]) return hits;
  }
  return [];
}

function resolve(q: string, ctx: HouseCtx): Product[] {
  const hits = findProducts(q, ctx.products);
  if (hits.length) return hits;
  if (/\b(this|that|it|same|the look|again|him|her|them)\b/i.test(q)) {
    return fromHistory(ctx.history, ctx.products);
  }
  return [];
}

function line(p: Product) {
  return `${p.sku} · Item ${String(p.n).padStart(2, "0")} · ${p.look} · ${zar(p.price)}`;
}

function card(p: Product) {
  return [
    line(p),
    p.blurb,
    "Subject to availability. No discount from this desk.",
  ].join("\n");
}

function whatsapp(p: Product, extra?: { size?: string; qty?: number }) {
  return [
    "SABLE.CO — 2026 lookbook",
    `Stock: ${p.sku}`,
    `Type: ${p.look}`,
    `Listed: ${zar(p.price)}`,
    extra?.size ? `Size: ${extra.size}` : null,
    extra?.qty ? `Qty: ${extra.qty}` : null,
    "Handmade. Subject to availability.",
    "Reply with UK size + pair count and I’ll confirm.",
  ]
    .filter(Boolean)
    .join("\n");
}

function salesBlocked(q: string) {
  return /\b(discount|off list|cost price|our cost|margin|wholesale|in stock|stock count|how many (?:do we have|left|in stock|pairs)|f&i|signio|gfv|luan.?s time|roadmap|owner time)\b/i.test(
    q,
  );
}

function adminOnly(ctx: HouseCtx, floorMsg: string, salesMsg: string) {
  if (atLeast(ctx.role, "manager")) return null;
  return salesMsg;
}

function listBlock(title: string, list: Product[], cap = 12) {
  if (!list.length) return `${title}: none in the 2026 book.`;
  const extra = list.length > cap ? `\n+ ${list.length - cap} more. Ask a 45xxx for the listed price.` : "";
  return `${title} (${list.length})\n` + list.slice(0, cap).map(line).join("\n") + extra;
}

export function runHouse(question: string, ctx: HouseCtx): HouseResult {
  const q = question.trim();
  const ql = q.toLowerCase();
  const canBuild = atLeast(ctx.role, "manager");
  const floor = atLeast(ctx.role, "manager");

  if (/^(help|what can you do|how do i|commands)\b/i.test(ql) || ql === "?") {
    if (canBuild) {
      return {
        text: [
          "Local house brain. Does not spend Grok usage.",
          "Quote: 45004 · item 8 · golfers · under 700 · WhatsApp for 45008",
          "Build: set 45004 to 1250 · rename 45008 to Cederberg · reset 45004",
          "File: note: Title — body",
          "Pages: set kicker to … · set blurb to … · feature items 1, 4, 15, 88",
          "reset house · Open Build for the table. Open Floor for the board.",
        ].join("\n"),
      };
    }
    return {
      text: floor
        ? "Ask a 45xxx, golfers, wool, a type, factory, invoices, or “WhatsApp for 45008”. Manager Build can change the house. I do not spend Grok usage."
        : "Ask a stock number like 45004, a type (vellie, golfer, chelsea), or “WhatsApp for 45004”. Listed prices only. I do not spend Grok usage.",
    };
  }

  if (!floor && salesBlocked(q)) {
    if (/discount|off list|cost|margin|wholesale/i.test(q)) {
      return { text: "Sales cannot set or quote a discount, cost, or margin. Listed price only. Escalate to a manager." };
    }
    if (/stock|how many/i.test(q)) {
      return { text: "Stock is subject to availability. Sales does not get a count. Ask a manager to confirm with the factory." };
    }
    return { text: "That file is not on the sales desk. Ask a manager." };
  }

  if (/\breset house\b|\breset (?:catalogue|overrides|prices)\b/i.test(ql)) {
    const deny = adminOnly(ctx, "Reset is admin Build only.", "Sales cannot reset the house.");
    if (deny) return { text: deny };
    ctx.resetOverrides?.();
    return { text: "Done. Catalogue prices, names, and page copy are back to the 2026 book.", did: "reset" };
  }

  const resetItem = q.match(/\breset\s+(?:item\s*)?(\d{1,3}|45\d{3}|sb-?26-?\d+)\b/i);
  if (resetItem && /price|list|item|sku|stock/i.test(q)) {
    const deny = adminOnly(ctx, "Price reset is admin Build only.", "Sales cannot change a listed price.");
    if (deny) return { text: deny };
    const hits = findProducts(q, ctx.products);
    if (!hits[0]) return { text: "Which stock number should go back to the catalogue listed price?" };
    ctx.clearPrice?.(hits[0].sku);
    return { text: `Done. ${hits[0].sku} is back to the catalogue listed price.`, did: "reset" };
  }

  const setPrice = q.match(
    /(?:set|change|update|make|price)\s+(?:item\s*)?(\d{1,3}|45\d{3}|sb-?26-?\d+)\s+(?:to\s*)?r?\s*(\d{3,5})/i,
  );
  const setPrice2 = q.match(
    /(?:45\d{3}|sb-?26-?\d+|item\s*\d{1,3}).{0,24}?(?:to|=)\s*r?\s*(\d{3,5})/i,
  );
  if (setPrice || (setPrice2 && /set|change|update|price|make/i.test(q))) {
    const deny = adminOnly(ctx, "Price changes are admin Build only.", "Sales cannot change a listed price.");
    if (deny) return { text: deny };
    const hits = findProducts(q, ctx.products);
    const amount = Number((setPrice && setPrice[2]) || (setPrice2 && setPrice2[1]));
    if (!hits[0] || !amount) return { text: "Tell me the 45xxx or item number and the new listed rand amount." };
    ctx.setPrice?.(hits[0].sku, amount);
    return {
      text: `Done. ${hits[0].sku} ${hits[0].look} listed ${zar(amount)}. Collection, Desk, Floor, and Enquire use this number.`,
      did: "price",
    };
  }

  const rename = q.match(/rename\s+(?:item\s*)?(\d{1,3}|45\d{3}|sb-?26-?\d+)\s+(?:to\s+)(.+)/i);
  if (rename) {
    const deny = adminOnly(ctx, "Renames are admin Build only.", "Sales cannot rename a look.");
    if (deny) return { text: deny };
    const hits = findProducts(q, ctx.products);
    const name = rename[2].trim().replace(/[.]+$/, "");
    if (!hits[0] || !name) return { text: "Give a stock number and the new name." };
    ctx.setLook?.(hits[0].sku, name);
    return { text: `Done. ${hits[0].sku} is now “${name}”. Type stays ${hits[0].type}.`, did: "look" };
  }

  const feature = q.match(/\bfeature(?:d)?(?:\s+items?)?\s+([\d,\sand]+)/i);
  if (feature && /feature/i.test(q)) {
    const deny = adminOnly(ctx, "Featured looks are admin Build only.", "Sales cannot change the house page.");
    if (deny) return { text: deny };
    const ns = feature[1]
      .split(/[^\d]+/)
      .map(Number)
      .filter((n) => n >= 1 && n <= 92)
      .slice(0, 4);
    if (!ns.length) return { text: "Give up to four item numbers, e.g. feature items 1, 4, 15, 88." };
    ctx.setFeatured?.(ns);
    const names = ns
      .map((n) => ctx.products.find((p) => p.n === n))
      .filter(Boolean)
      .map((p) => `${p!.sku} ${p!.look}`)
      .join(", ");
    return { text: `Done. House page selected looks: ${names}.`, did: "featured" };
  }

  const setCopy = q.match(
    /^set\s+(kicker|hero|title|blurb|why|story|share|delivery note|factory title|factory lead|factory body)\s+(?:to\s+)?([\s\S]+)/i,
  );
  if (setCopy) {
    const deny = adminOnly(ctx, "Page copy is Build only.", "Sales cannot change the house page.");
    if (deny) return { text: deny };
    const key = setCopy[1].toLowerCase();
    const value = setCopy[2].trim();
    const map: Record<string, keyof HouseCopy> = {
      kicker: "kicker",
      hero: "title",
      title: "title",
      blurb: "blurb",
      why: "why",
      story: "story",
      share: "shareLine",
      "delivery note": "deliveryNote",
      "factory title": "factoryTitle",
      "factory lead": "factoryLead",
      "factory body": "factoryBody",
    };
    const field = map[key];
    if (!field) return { text: "I can set kicker, title, blurb, why, story, share, or factory copy." };
    ctx.setCopy?.({ [field]: value });
    return { text: `Done. ${key} is live on the house page.`, did: "copy" };
  }

  const noteWrite = q.match(/^(?:note|remember|file):\s*(.+?)\s*[—:-]\s*([\s\S]+)/i);
  if (noteWrite) {
    const deny = adminOnly(ctx, "New house files are admin Build only.", "Sales cannot file a house note.");
    if (deny) return { text: deny };
    const title = noteWrite[1].trim();
    const body = noteWrite[2].trim();
    const existing = ctx.notes.find(
      (n) => n.title.toLowerCase() === title.toLowerCase() || n.slug === title.toLowerCase(),
    );
    if (existing) {
      ctx.setNoteBody?.(existing.slug, body);
      return { text: `Updated “${existing.title}”.`, did: "note" };
    }
    const slug = title.toLowerCase().replace(/[^a-z0-9]+/g, "-").slice(0, 40);
    ctx.addNote?.({
      slug: `custom-${slug}-${Date.now().toString(36)}`,
      title,
      tag: "Build",
      minRole: "manager",
      body,
    });
    return { text: `Filed “${title}” into house memory (manager+).`, did: "note" };
  }

  if (/\bwhatsapp|wa message|outbound|script|write the message|draft (?:a |the )?message\b/i.test(ql)) {
    const hits = resolve(q, ctx);
    if (!hits[0]) return { text: "Which 45xxx or type should I put on the WhatsApp line?" };
    const size = q.match(/\bsize\s+(\d{1,2}(?:\.5)?)\b/i)?.[1];
    const qty = Number(q.match(/\b(?:qty|x|pairs?)\s+(\d{1,2})\b/i)?.[1] ?? 0) || undefined;
    ctx.addEnquiry?.({
      sku: hits[0].sku,
      look: hits[0].look,
      size: size ?? "",
      qty: qty ?? 1,
      name: "",
      phone: "",
      note: "desk-draft",
      delivery: "collect",
      deliveryFee: 0,
    });
    return { text: whatsapp(hits[0], { size, qty }), did: "enquiry" };
  }

  if (/\bcompare\b|\bvs\b|\bagainst\b/i.test(ql)) {
    const nums = [...q.matchAll(/(?:item\s*)?(\d{1,3}|45\d{3}|sb-?26-?\d+)/gi)]
      .map((m) => findProducts(String(m[0]), ctx.products)[0])
      .filter(Boolean);
    const unique = [...new Map(nums.map((p) => [p!.sku, p!])).values()].slice(0, 3);
    if (unique.length < 2) return { text: "Name two stock numbers, e.g. compare 45004 and 45090." };
    return {
      text: unique
        .map((p) => `${line(p)}\n${p.blurb}`)
        .join("\n\n") + "\n\nListed ZAR only. Subject to availability.",
    };
  }

  if (floor && /\b(cost|margin|profit|factory price)\b/.test(ql)) {
    const hits = resolve(q, ctx);
    if (hits[0]) {
      const profit = hits[0].price - hits[0].cost;
      return {
        text: `${line(hits[0])}\nFactory cost ${zar(hits[0].cost)}. About ${zar(profit)} on the pair. Sales never see this.`,
      };
    }
  }

  if (/\bgolfer/.test(ql)) {
    return { text: listBlock("Golfers", ctx.products.filter((p) => p.type === "Golfer")) };
  }
  if (/\bwool/.test(ql)) {
    return { text: listBlock("Wool lined", ctx.products.filter((p) => p.category === "Wool lined")) };
  }
  if (/\bchelsea/.test(ql)) {
    return { text: listBlock("Chelsea", ctx.products.filter((p) => p.type === "Chelsea")) };
  }
  if (/\bderby/.test(ql)) {
    return { text: listBlock("Derby", ctx.products.filter((p) => p.type === "Derby")) };
  }
  if (/\bvellie/.test(ql)) {
    return {
      text: listBlock(
        "Vellie",
        ctx.products.filter((p) => p.type === "Vellie" || p.type === "Wool-lined vellie"),
      ),
    };
  }
  if (/\bhiking/.test(ql)) {
    return { text: listBlock("Hiking boot", ctx.products.filter((p) => p.type === "Hiking boot")) };
  }
  if (/\bcombat/.test(ql)) {
    return { text: listBlock("Combat boot", ctx.products.filter((p) => p.type === "Combat boot")) };
  }
  if (/\bkids?\b/.test(ql)) {
    return { text: listBlock("Kids", ctx.products.filter((p) => p.category === "Kids")) };
  }

  if (/\bentry\b|under\s*500|r?399|r?449/.test(ql) && !/item|45\d{3}/.test(ql)) {
    return {
      text: listBlock(
        "Entry",
        ctx.products.filter((p) => p.price <= 449),
      ),
    };
  }
  const under = q.match(/\bunder\s*r?\s*(\d{3,5})\b/i);
  if (under) {
    const cap = Number(under[1]);
    return {
      text: listBlock(
        `Under ${zar(cap)}`,
        ctx.products.filter((p) => p.price < cap),
        16,
      ),
    };
  }
  if (/\batelier\b|top (?:end|tier)|most expensive/.test(ql)) {
    return {
      text: listBlock(
        "Atelier",
        ctx.products.filter((p) => p.price >= 1400),
      ),
    };
  }
  if (/\beveryday\b|\bdaily\b|\bweek\b/.test(ql)) {
    return {
      text: listBlock(
        "Everyday (R599–R699)",
        ctx.products.filter((p) => p.price >= 599 && p.price <= 699),
        14,
      ),
    };
  }
  if (/\bwinter\b|\bhighveld\b|\bcold\b/.test(ql)) {
    return { text: listBlock("Wool lined", ctx.products.filter((p) => p.category === "Wool lined")) };
  }
  if (/\bgolf\b|\bveldskoen\b|\bcrepe\b/.test(ql)) {
    return { text: listBlock("Golfers", ctx.products.filter((p) => p.type === "Golfer")) };
  }

  if (floor && /\benquir/.test(ql)) {
    const list = ctx.enquiries ?? [];
    if (!list.length) return { text: "No enquiries on this device yet. Open Floor to capture a person." };
    return {
      text:
        `Device ledger (${list.length})\n` +
        list
          .slice(0, 8)
          .map((e) => `${e.look} · ${e.sku} · size ${e.size || "—"} · qty ${e.qty} · ${e.name || "anon"}`)
          .join("\n"),
    };
  }

  const hits = resolve(q, ctx);
  if (hits.length === 1) return { text: card(hits[0]) };
  if (hits.length > 1) return { text: hits.map(line).join("\n") };

  if (floor && /factory|own factory|lead time/.test(ql)) {
    const n = ctx.notes.find((x) => x.slug === "factory");
    if (n) return { text: `${n.title}\n\n${n.body}` };
  }

  const noteHits = ctx.notes.filter((n) => {
    const hay = `${n.title} ${n.tag} ${n.body}`.toLowerCase();
    return ql.split(/\s+/).some((w) => w.length > 3 && hay.includes(w));
  });
  if (noteHits[0]) {
    return { text: `${noteHits[0].title}\n\n${noteHits[0].body}` };
  }

  return { text: "No match in the house files. Try a stock number like 45004, a type (vellie, golfer), or golfers." };
}
