import type { DeliveryKind } from "@/lib/money";
import type { AssignedBy, SellerId } from "@/lib/people";

export const STAGES = [
  "new",
  "contacted",
  "qualified",
  "negotiation",
  "closed",
  "lost",
] as const;

export type Stage = (typeof STAGES)[number];

export const STAGE_LABEL: Record<Stage, string> = {
  new: "New",
  contacted: "Contacted",
  qualified: "Qualified",
  negotiation: "Negotiation",
  closed: "Closed",
  lost: "Lost",
};

export const SOURCES = [
  "whatsapp",
  "website",
  "instagram",
  "walk-in",
  "referral",
  "other",
] as const;

export type Source = (typeof SOURCES)[number];

export const SOURCE_LABEL: Record<Source, string> = {
  whatsapp: "WhatsApp",
  website: "Website",
  instagram: "Instagram",
  "walk-in": "Walk-in",
  referral: "Referral",
  other: "Other",
};

export const UK_SIZES = ["3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13"] as const;

export type Lead = {
  id: string;
  name: string;
  phone: string;
  sku: string;
  look: string;
  size: string;
  qty: number;
  source: Source;
  status: Stage;
  note: string;
  address: string;
  delivery: DeliveryKind;
  deliveryFee: number;
  owner: SellerId | null;
  assignedBy: AssignedBy | null;
  orderId: string | null;
  nextAction: string;
  nextActionAt: string | null;
  at: string;
  updatedAt: string;
};

export type InvoiceStatus = "open" | "paid";

export type Invoice = {
  id: string;
  number: string;
  leadId: string | null;
  name: string;
  phone: string;
  address: string;
  sku: string;
  look: string;
  size: string;
  qty: number;
  unitPrice: number;
  delivery: DeliveryKind;
  deliveryFee: number;
  note: string;
  owner: SellerId | null;
  at: string;
  status: InvoiceStatus;
};

export function nextInvoiceNumber(existing: Invoice[]) {
  const n = existing.length + 1;
  return `INV-${String(n).padStart(4, "0")}`;
}

export function waHref(phone: string, text: string) {
  const digits = phone.replace(/\D/g, "");
  const za =
    digits.startsWith("0") && digits.length === 10
      ? `27${digits.slice(1)}`
      : digits.startsWith("27")
        ? digits
        : digits;
  const base = za ? `https://wa.me/${za}` : "https://wa.me/";
  return `${base}?text=${encodeURIComponent(text)}`;
}

export function firstContact(name: string, sku: string, look: string, price: string) {
  const who = name.trim() ? `Hi ${name.trim()}` : "Hi";
  return [
    `${who}, this is SABLE.CO.`,
    `Stock ${sku} · ${look} · ${price}.`,
    "Handmade. Subject to availability.",
    "Reply with UK size and pair count and I will confirm.",
  ].join(" ");
}

export function shareUrl() {
  if (typeof window === "undefined") return "https://sable.co";
  return window.location.origin + "/";
}
