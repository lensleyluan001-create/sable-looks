/** House sellers and the locked commission split on pair profit. */

export const SELLERS = ["wian", "luan", "dylan"] as const;
export type SellerId = (typeof SELLERS)[number];

export const SELLER_LABEL: Record<SellerId, string> = {
  wian: "Wian",
  luan: "Luan",
  dylan: "Dylan",
};

export type AssignedBy = "manager" | "auto" | "sales";

export type Split = {
  wian: number;
  luan: number;
  dylan: number;
  house: number;
};

/** Fractions of pair profit. Always sums to 1. */
export function commissionSplit(seller: SellerId): Split {
  if (seller === "wian") return { wian: 0.2, luan: 0.4, dylan: 0.3, house: 0.1 };
  if (seller === "luan") return { wian: 0, luan: 0.6, dylan: 0.3, house: 0.1 };
  return { wian: 0, luan: 0, dylan: 0.9, house: 0.1 };
}

export function splitProfit(profit: number, seller: SellerId) {
  const p = Math.max(0, Math.round(profit));
  const frac = commissionSplit(seller);
  const wian = Math.round(p * frac.wian);
  const luan = Math.round(p * frac.luan);
  const dylan = Math.round(p * frac.dylan);
  const house = Math.max(0, p - wian - luan - dylan);
  return { wian, luan, dylan, house, profit: p };
}

export function pairProfit(listed: number, cost: number, qty: number) {
  return Math.max(0, Math.round(listed) - Math.round(cost)) * Math.max(1, Math.round(qty) || 1);
}

export function isSeller(value: string | null | undefined): value is SellerId {
  return value === "wian" || value === "luan" || value === "dylan";
}

export function nextSeller(last: SellerId | null): SellerId {
  if (last === "wian") return "luan";
  if (last === "luan") return "dylan";
  return "wian";
}

export const AUTO_ASSIGN_MINUTES = 30;
