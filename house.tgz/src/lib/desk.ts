import { createServerFn } from "@tanstack/react-start";

export const openDesk = createServerFn({ method: "POST" })
  .validator((d: { code: string }) => ({ code: String(d?.code ?? "") }))
  .handler(async ({ data }) => {
    const { roleFromCode, signRole } = await import("@/lib/desk.server");
    const role = roleFromCode(data.code);
    if (!role) return { ok: false as const, error: "Wrong desk code." };
    const token = await signRole(role);
    return { ok: true as const, role, token };
  });
