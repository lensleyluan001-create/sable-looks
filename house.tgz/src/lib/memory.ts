import type { Role } from "@/lib/access";

export type MemoryNote = {
  slug: string;
  title: string;
  tag: string;
  minRole: Role;
  body: string;
};

export const MEMORY: MemoryNote[] = [
  {
    slug: "brand",
    title: "Brand bible",
    tag: "Identity",
    minRole: "sales",
    body: `SABLE.CO is a leather footwear house with its own factory. Language: our shoes.

Tagline locked from the 2026 catalogue: Modern comfort. Timeless character.

We make vellies, golfers, chelseas, derbies and boots. Not seasonal fashion. Not imported white-label.

Voice: quiet, direct, South African. Never hype. Never “luxury lifestyle” fluff.`,
  },
  {
    slug: "collection",
    title: "2026 collection",
    tag: "Range",
    minRole: "sales",
    body: `Source of truth: Sable 2026 Minimal Catalogue, locked to stock numbers.

92 pairs. Item N = stock 4500N. Track every shoe as 45001–45092.
The name on the floor is the type (Vellie, Golfer, Chelsea…). Factory stamps still to come.

Golfers: 45004, 45023, 45047, 45060, 45063, 45090.
Wool lined: 45008, 45009, 45010, 45057.
Kids: 45078, 45079.

Prices as listed, ZAR, subject to availability. Photo is /shoes/{stock}.jpg.`,
  },
  {
    slug: "pricing",
    title: "Pricing band",
    tag: "Money",
    minRole: "sales",
    body: `From the 2026 catalogue. Do not round in client quotes — use listed ZAR.

- Entry: R399–R449 (kids, sandals, thongs)
- Core everyday: R599–R699
- Mid: R799–R899
- Golfers: R850–R1300
- Wool lined: R699–R799
- Atelier: R1100–R1600 (chelsea, combat, hiking)

Never invent a discount. If a buyer wants a number off list, say a manager will confirm.`,
  },
  {
    slug: "delivery",
    title: "Delivery",
    tag: "Send",
    minRole: "sales",
    body: `Collect if they are close.

Default fees (manager can change these in Build):
- Local: R100
- International: R300
- Custom: type a number on the lead or invoice

Do not promise a date. Confirm the pair is on the bench, then send.`,
  },
  {
    slug: "sales",
    title: "Sales path",
    tag: "Floor",
    minRole: "sales",
    body: `WhatsApp-first. South Africa. Send stock 45xxx + type + listed price + delivery + “subject to availability”.

Capture the person on Floor. Raise an invoice when the pair is going.
Do not promise a pair until factory/manager confirms stock.
One follow-up if they ghost after price, then park as lost.`,
  },
  {
    slug: "whatsapp",
    title: "WhatsApp script",
    tag: "Copy",
    minRole: "sales",
    body: `Default outbound:

SABLE.CO — 2026 lookbook
Stock: 4500X
Type: [Vellie / Golfer / Chelsea]
Listed: R[listed]
Delivery: Collect / Local R100 / International R300
Handmade. Subject to availability.
Reply with UK size + pair count and I’ll confirm.`,
  },
  {
    slug: "factory",
    title: "Factory",
    tag: "Make",
    minRole: "manager",
    body: `Own factory. Lasts, cut hides, local hands.

Commercially:
- Lead times are ours
- Quality comes back to us
- 92 stock numbers is range and an ops load

Do not let sales promise stock we have not confirmed.
Cost rule: about R200 on the pair. 45001 factory cost is R350. Sales never see cost.`,
  },
  {
    slug: "operating",
    title: "Operating rule",
    tag: "Priority",
    minRole: "manager",
    body: `Owner: Luan Lensley. Sable is the live desk.

Get the house up: lookbook, floor, invoices, delivery, the public page people can share.

Other work is on hold. Do not pull it into this house. Do not brief sales on it.

When the day is Sable: move stock, confirm availability, raise the invoice, send the pair.`,
  },
  {
    slug: "access",
    title: "Who sees what",
    tag: "Access",
    minRole: "manager",
    body: `Public page: house, collection, enquire. No floor.

Sales desk (veld): lookbook, listed prices, WhatsApp, enquire, floor capture, invoices. No factory internals, no cost, no discounts, no desk codes.

Manager (last) and admin (4181): full house. Build can change prices, names, page copy, delivery fees, invoice wording, memory.

The assistant is bound to the same split.`,
  },
  {
    slug: "vault",
    title: "Obsidian vault",
    tag: "Store",
    minRole: "manager",
    body: `Canonical house store: Google Drive → Sable Sales → obsidion sable.

Living Grok skill: Google Drive → Sable Sales → Luan second self. Sable only for now.

Open in Obsidian as a vault (mirror mode).

Sales do not get these Drive folders.`,
  },
  {
    slug: "roadmap",
    title: "Next build",
    tag: "Later",
    minRole: "manager",
    body: `Live now: 45xxx lookbook, public house page, share, floor, invoices, local R100 / international R300 (flexible), manager+admin Build.

Desk is the local house brain. It does not spend Grok usage.

Only if Luan asks:
1. Factory stamps / official names on top of type
2. Size run + last chart
3. Real stock counts from factory
4. Shared Neon ledger (this preview is on-device)
5. Card payments`,
  },
];

export function notesFor(role: Role) {
  return MEMORY.filter((n) => {
    if (n.minRole === "sales") return true;
    if (n.minRole === "manager") return role === "manager" || role === "admin";
    return role === "admin";
  });
}
