import { PRODUCTS, parseStock } from "@/lib/catalogue";
import { verifyDesk } from "@/lib/desk.server";
import { UK_SIZES } from "@/lib/floor";
import type { DeliveryKind } from "@/lib/money";
import type { HouseOrder, OrderStatus, PlaceOrderInput } from "@/lib/orders";
import {
  AUTO_ASSIGN_MINUTES,
  isSeller,
  nextSeller,
  type AssignedBy,
  type SellerId,
} from "@/lib/people";

function asDelivery(raw: string): DeliveryKind {
  if (raw === "local" || raw === "international" || raw === "custom" || raw === "collect") {
    return raw;
  }
  return "collect";
}

function asStatus(raw: string): OrderStatus {
  if (raw === "assigned" || raw === "closed" || raw === "lost") return raw;
  return "new";
}

function asAssignedBy(raw: string | null): AssignedBy | null {
  if (raw === "manager" || raw === "auto" || raw === "sales") return raw;
  return null;
}

function iso(value: unknown) {
  if (!value) return null;
  if (value instanceof Date) return value.toISOString();
  const s = String(value);
  const d = new Date(s);
  return Number.isNaN(d.getTime()) ? s : d.toISOString();
}

type OrderRow = {
  id: string;
  sku: string;
  look: string;
  size: string;
  qty: number;
  name: string;
  phone: string;
  address: string;
  note: string;
  delivery: string;
  delivery_fee: number;
  unit_price: number;
  assigned_to: string | null;
  assigned_by: string | null;
  assigned_at: unknown;
  status: string;
  created_at: unknown;
};

function toOrder(row: OrderRow): HouseOrder {
  return {
    id: String(row.id),
    sku: String(row.sku),
    look: String(row.look),
    size: String(row.size),
    qty: Number(row.qty) || 1,
    name: String(row.name),
    phone: String(row.phone),
    address: String(row.address ?? ""),
    note: String(row.note ?? ""),
    delivery: asDelivery(String(row.delivery ?? "collect")),
    deliveryFee: Number(row.delivery_fee) || 0,
    unitPrice: Number(row.unit_price) || 0,
    assignedTo: isSeller(row.assigned_to) ? row.assigned_to : null,
    assignedBy: asAssignedBy(row.assigned_by),
    assignedAt: iso(row.assigned_at),
    status: asStatus(String(row.status ?? "new")),
    createdAt: iso(row.created_at) ?? new Date().toISOString(),
  };
}

async function sql() {
  const { getSql } = await import("@/lib/db");
  return getSql();
}

async function loadMeta(db: Awaited<ReturnType<typeof sql>>) {
  const rows = await db.query<{ value: string }>(
    "select value from house_meta where key = $1",
    ["last_seller"],
  );
  const raw = rows[0]?.value ?? "dylan";
  return isSeller(raw) ? raw : ("dylan" as SellerId);
}

async function setMeta(db: Awaited<ReturnType<typeof sql>>, seller: SellerId) {
  await db.query(
    "insert into house_meta (key, value) values ($1, $2) on conflict (key) do update set value = $2",
    ["last_seller", seller],
  );
}

async function assignRow(
  db: Awaited<ReturnType<typeof sql>>,
  id: string,
  seller: SellerId,
  by: AssignedBy,
) {
  await db.query(
    `update house_orders
     set assigned_to = $1, assigned_by = $2, assigned_at = now(), status = 'assigned'
     where id = $3`,
    [seller, by, id],
  );
}

async function autoAssignDue() {
  const db = await sql();
  const open = await db.query<OrderRow>(
    `select * from house_orders
     where assigned_to is null and status = 'new'
     order by created_at asc`,
  );
  const cutoff = Date.now() - AUTO_ASSIGN_MINUTES * 60_000;
  const due = open.filter((row) => {
    const at = iso(row.created_at);
    return at ? new Date(at).getTime() <= cutoff : false;
  });
  if (due.length === 0) return;
  let last = await loadMeta(db);
  for (const row of due) {
    const seller = nextSeller(last);
    await assignRow(db, row.id, seller, "auto");
    last = seller;
  }
  await setMeta(db, last);
}

export function parsePlaceInput(d: PlaceOrderInput) {
  return {
    sku: parseStock(String(d?.sku ?? "")) ?? "",
    size: String(d?.size ?? "").trim(),
    qty: Math.max(1, Math.min(6, Math.round(Number(d?.qty) || 1))),
    name: String(d?.name ?? "").trim(),
    phone: String(d?.phone ?? "").trim(),
    address: String(d?.address ?? "").trim(),
    note: String(d?.note ?? "").trim(),
    delivery: asDelivery(String(d?.delivery ?? "collect")),
    deliveryFee: Math.max(0, Math.round(Number(d?.deliveryFee) || 0)),
  };
}

export async function insertHouseOrder(data: ReturnType<typeof parsePlaceInput>) {
  const shoe = PRODUCTS.find((p) => p.sku === data.sku);
  if (!shoe) return { ok: false as const, error: "That stock number is not in the book." };
  if (!(UK_SIZES as readonly string[]).includes(data.size)) {
    return { ok: false as const, error: "Pick a UK size." };
  }
  if (data.name.length < 2) return { ok: false as const, error: "Name is required." };
  if (data.phone.replace(/\D/g, "").length < 9) {
    return { ok: false as const, error: "Phone is required." };
  }
  const db = await sql();
  const id = crypto.randomUUID();
  await db.query(
    `insert into house_orders (
      id, sku, look, size, qty, name, phone, address, note,
      delivery, delivery_fee, unit_price, status
    ) values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,'new')`,
    [
      id,
      shoe.sku,
      shoe.look,
      data.size,
      data.qty,
      data.name,
      data.phone,
      data.address,
      data.note,
      data.delivery,
      data.deliveryFee,
      shoe.price,
    ],
  );
  const rows = await db.query<OrderRow>("select * from house_orders where id = $1", [id]);
  return { ok: true as const, order: rows[0] ? toOrder(rows[0]) : null };
}

export async function fetchHouseOrders(token: string) {
  const role = await verifyDesk(token);
  if (!role) return { ok: false as const, error: "Desk required." };
  await autoAssignDue();
  const db = await sql();
  const rows = await db.query<OrderRow>(
    "select * from house_orders order by created_at desc limit 200",
  );
  return { ok: true as const, role, orders: rows.map(toOrder) };
}

export async function setHouseOrderSeller(token: string, id: string, seller: string) {
  const role = await verifyDesk(token);
  if (!role || (role !== "manager" && role !== "admin")) {
    return { ok: false as const, error: "A manager assigns the deal." };
  }
  if (!isSeller(seller)) return { ok: false as const, error: "Pick Wian, Luan or Dylan." };
  const db = await sql();
  const existing = await db.query<OrderRow>("select * from house_orders where id = $1", [id]);
  if (!existing[0]) return { ok: false as const, error: "Deal not found." };
  await assignRow(db, id, seller, "manager");
  await setMeta(db, seller);
  const rows = await db.query<OrderRow>("select * from house_orders where id = $1", [id]);
  return { ok: true as const, order: rows[0] ? toOrder(rows[0]) : null };
}

export async function autoPickHouseOrder(token: string, id: string) {
  const role = await verifyDesk(token);
  if (!role || (role !== "manager" && role !== "admin")) {
    return { ok: false as const, error: "A manager assigns the deal." };
  }
  const db = await sql();
  const existing = await db.query<OrderRow>("select * from house_orders where id = $1", [id]);
  if (!existing[0]) return { ok: false as const, error: "Deal not found." };
  if (isSeller(existing[0].assigned_to)) {
    return { ok: true as const, order: toOrder(existing[0]) };
  }
  const last = await loadMeta(db);
  const seller = nextSeller(last);
  await assignRow(db, id, seller, "auto");
  await setMeta(db, seller);
  const rows = await db.query<OrderRow>("select * from house_orders where id = $1", [id]);
  return { ok: true as const, order: rows[0] ? toOrder(rows[0]) : null };
}
