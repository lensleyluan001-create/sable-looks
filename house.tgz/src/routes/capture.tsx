import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { ChipRow, chipClass } from "@/components/chip-row";
import { DeliveryPick } from "@/components/delivery-pick";
import { Input, Label } from "@/components/ui/input";
import { SellerPick } from "@/components/seller-pick";
import { StaffOnly } from "@/components/staff-gate";
import { FILTERS, matchesFilter, type Filter } from "@/lib/catalogue";
import { SOURCE_LABEL, SOURCES, UK_SIZES, type Source } from "@/lib/floor";
import { liveBySku, useLiveProducts } from "@/lib/live";
import { deliveryFee, type DeliveryKind } from "@/lib/money";
import type { SellerId } from "@/lib/people";
import { useSable } from "@/lib/store";
import { cn, zar } from "@/lib/utils";

type Search = { sku?: string };

export const Route = createFileRoute("/capture")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    sku: typeof s.sku === "string" ? s.sku : undefined,
  }),
  component: CaptureRoute,
});

function CaptureRoute() {
  return (
    <StaffOnly>
      <CapturePage />
    </StaffOnly>
  );
}

function CapturePage() {
  const { sku: seed } = Route.useSearch();
  const products = useLiveProducts();
  const addLead = useSable((s) => s.addLead);
  const rates = useSable((s) => s.delivery);
  const navigate = useNavigate();
  const [sku, setSku] = useState(seed ?? "45001");
  const [filter, setFilter] = useState<Filter>("All");
  const [q, setQ] = useState("");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [size, setSize] = useState("");
  const [qty, setQty] = useState(1);
  const [source, setSource] = useState<Source>("whatsapp");
  const [note, setNote] = useState("");
  const [address, setAddress] = useState("");
  const [delivery, setDelivery] = useState<DeliveryKind>("collect");
  const [customFee, setCustomFee] = useState(0);
  const [owner, setOwner] = useState<SellerId | null>(null);

  useEffect(() => {
    if (seed) setSku(seed);
  }, [seed]);

  const product = liveBySku(products, sku) ?? products[0];
  const list = useMemo(() => {
    const s = q.trim().toLowerCase();
    return products.filter((p) => {
      if (!matchesFilter(p, filter)) return false;
      if (!s) return true;
      return (
        p.sku.includes(s) ||
        p.look.toLowerCase().includes(s) ||
        p.type.toLowerCase().includes(s)
      );
    });
  }, [products, filter, q]);

  if (!product) return null;

  function submit() {
    if (!product) return;
    const lead = addLead({
      name: name.trim() || "No name",
      phone: phone.trim(),
      sku: product.sku,
      look: product.look,
      size,
      qty,
      source,
      note,
      address,
      delivery,
      deliveryFee: deliveryFee(delivery, rates, customFee),
      owner,
      assignedBy: owner ? "sales" : null,
    });
    void navigate({ to: "/leads/$id", params: { id: lead.id } });
  }

  return (
    <main className="mx-auto max-w-6xl px-4 py-8 sm:px-6 sm:py-10">
      <p className="text-xs tracking-[0.24em] uppercase text-muted">New person</p>
      <h1 className="font-display mt-2 text-4xl">Capture</h1>
      <p className="mt-3 max-w-xl text-sm text-muted">
        Pick the 45xxx. Listed price comes with it. Cost stays off the sales desk.
      </p>

      <form
        className="mt-8 grid min-w-0 gap-10 lg:grid-cols-[minmax(0,1fr)_320px]"
        onSubmit={(e) => {
          e.preventDefault();
          submit();
        }}
      >
        <aside className="order-1 min-w-0 space-y-4 lg:order-2 lg:sticky lg:top-24 lg:self-start">
          <div className="overflow-hidden rounded-[var(--radius-lg)] border border-border bg-elevated">
            <div className="flex gap-3 sm:block">
              <img
                src={product.image}
                alt={product.sku}
                className="h-28 w-28 shrink-0 object-cover sm:aspect-[4/3] sm:h-auto sm:w-full"
              />
              <div className="flex min-w-0 flex-col justify-center py-3 pr-3 sm:p-4 sm:pr-4">
                <p className="font-display text-2xl tabular-nums">{product.sku}</p>
                <p className="text-sm text-muted">
                  {product.look} · {zar(product.price)}
                </p>
              </div>
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="name">Name</Label>
            <Input id="name" value={name} onChange={(e) => setName(e.target.value)} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="phone">Phone</Label>
            <Input id="phone" value={phone} onChange={(e) => setPhone(e.target.value)} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label htmlFor="size">UK size</Label>
              <select
                id="size"
                value={size}
                onChange={(e) => setSize(e.target.value)}
                className="flex h-11 w-full rounded-[var(--radius-sm)] border border-border bg-elevated px-3 text-sm text-fg"
              >
                <option value="">Later</option>
                {UK_SIZES.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="qty">Qty</Label>
              <Input
                id="qty"
                type="number"
                min={1}
                value={qty}
                onChange={(e) => setQty(Number(e.target.value) || 1)}
              />
            </div>
          </div>
          <DeliveryPick
            kind={delivery}
            custom={customFee}
            rates={rates}
            onKind={setDelivery}
            onCustom={setCustomFee}
          />
          <div className="space-y-2">
            <Label htmlFor="address">Address</Label>
            <Input id="address" value={address} onChange={(e) => setAddress(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label>Seller</Label>
            <SellerPick value={owner} onChange={setOwner} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="source">Source</Label>
            <select
              id="source"
              value={source}
              onChange={(e) => setSource(e.target.value as Source)}
              className="flex h-11 w-full rounded-[var(--radius-sm)] border border-border bg-elevated px-3 text-sm text-fg"
            >
              {SOURCES.map((s) => (
                <option key={s} value={s}>
                  {SOURCE_LABEL[s]}
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="note">Note</Label>
            <Input id="note" value={note} onChange={(e) => setNote(e.target.value)} />
          </div>
          <Button type="submit" className="w-full" size="lg">
            Put on the board
          </Button>
        </aside>

        <div className="order-2 min-w-0 lg:order-1">
          <p className="mb-3 text-xs tracking-[0.16em] uppercase text-muted">Pick the pair</p>
          <ChipRow edge>
            {FILTERS.map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => setFilter(c)}
                className={chipClass(filter === c)}
              >
                {c}
              </button>
            ))}
          </ChipRow>
          <div className="mt-4 max-w-xs">
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search 45004, chelsea…"
            />
          </div>
          <div className="mt-4 grid grid-cols-3 gap-2 sm:grid-cols-4 sm:gap-3 md:grid-cols-5">
            {list.map((p) => (
              <button
                key={p.sku}
                type="button"
                onClick={() => setSku(p.sku)}
                className={cn(
                  "overflow-hidden rounded-[var(--radius-md)] border text-left",
                  sku === p.sku ? "border-primary" : "border-border",
                )}
              >
                <img src={p.image} alt={p.sku} className="aspect-square w-full object-cover" />
                <span className="block px-1.5 py-2 sm:px-2">
                  <span className="block text-xs tabular-nums">{p.sku}</span>
                  <span className="block truncate text-[10px] uppercase tracking-wider text-muted sm:text-xs">
                    {p.look}
                  </span>
                </span>
              </button>
            ))}
          </div>
        </div>
      </form>
    </main>
  );
}
