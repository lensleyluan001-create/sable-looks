import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { DeliveryPick } from "@/components/delivery-pick";
import { Input, Label } from "@/components/ui/input";
import { SizePick } from "@/components/size-pick";
import { liveBySku, useLiveProducts } from "@/lib/live";
import { DELIVERY_LABEL, deliveryFee, type DeliveryKind } from "@/lib/money";
import { placeOrder } from "@/lib/house-orders";
import { useSable } from "@/lib/store";
import { zar } from "@/lib/utils";

type Search = { sku?: string; size?: string };

export const Route = createFileRoute("/order")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    sku: typeof s.sku === "string" ? s.sku : undefined,
    size: typeof s.size === "string" ? s.size : undefined,
  }),
  component: OrderPage,
});

function OrderPage() {
  const { sku: seed, size: sizeSeed } = Route.useSearch();
  const products = useLiveProducts();
  const rates = useSable((s) => s.delivery);
  const navigate = useNavigate();
  const [sku, setSku] = useState(seed ?? products[0]?.sku ?? "");
  const [size, setSize] = useState(sizeSeed ?? "");
  const [qty, setQty] = useState(1);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [note, setNote] = useState("");
  const [delivery, setDelivery] = useState<DeliveryKind>("collect");
  const [customFee, setCustomFee] = useState(0);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (seed) setSku(seed);
  }, [seed]);
  useEffect(() => {
    if (sizeSeed) setSize(sizeSeed);
  }, [sizeSeed]);

  const product = liveBySku(products, sku) ?? products[0];
  const fee = deliveryFee(delivery, rates, customFee);
  const total = product ? product.price * qty + fee : 0;

  const summary = useMemo(() => {
    if (!product) return "";
    return [
      `${product.sku} · ${product.look}`,
      size ? `UK ${size}` : "Size to pick",
      `×${qty}`,
      zar(product.price),
      DELIVERY_LABEL[delivery],
    ].join(" · ");
  }, [product, size, qty, delivery]);

  if (!product) return null;

  async function submit() {
    if (!product) return;
    setError("");
    setBusy(true);
    try {
      const res = await placeOrder({
        data: {
          sku: product.sku,
          size,
          qty,
          name: name.trim(),
          phone: phone.trim(),
          address: address.trim(),
          note: note.trim(),
          delivery,
          deliveryFee: fee,
        },
      });
      if (!res.ok || !res.order) {
        setError(res.ok ? "Could not log the order." : res.error);
        return;
      }
      void navigate({
        to: "/thanks",
        search: { sku: product.sku, name: res.order.name },
      });
    } catch {
      setError("The house could not take that just now. Try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="mx-auto grid max-w-6xl gap-10 px-4 py-8 sm:grid-cols-2 sm:px-6 sm:py-10">
      <div className="min-w-0">
        <p className="text-xs tracking-[0.24em] uppercase text-muted">Request a pair</p>
        <h1 className="font-display mt-2 text-4xl sm:text-5xl">Order</h1>
        <p className="mt-3 max-w-md text-sm leading-relaxed text-muted">
          No card on this page. You send the 45xxx and your UK size. We confirm the
          pair is on the bench. Then we WhatsApp you. Listed price. Subject to
          availability.
        </p>

        <ol className="mt-8 grid gap-4 text-sm sm:grid-cols-3">
          {[
            ["01", "Pick the pair"],
            ["02", "UK size and send"],
            ["03", "We confirm, then EFT"],
          ].map(([n, t]) => (
            <li key={n} className="border-t border-border pt-3">
              <p className="text-xs tabular-nums text-subtle">{n}</p>
              <p className="mt-2">{t}</p>
            </li>
          ))}
        </ol>

        <form
          className="mt-10 space-y-4"
          onSubmit={(e) => {
            e.preventDefault();
            void submit();
          }}
        >
          <div className="space-y-2">
            <Label htmlFor="sku">Stock</Label>
            <select
              id="sku"
              value={sku}
              onChange={(e) => setSku(e.target.value)}
              className="flex h-11 w-full rounded-[var(--radius-sm)] border border-border bg-elevated px-3 text-sm text-fg"
            >
              {products.map((p) => (
                <option key={p.sku} value={p.sku}>
                  {p.sku} · {p.look} · {zar(p.price)}
                </option>
              ))}
            </select>
          </div>
          <SizePick value={size} onChange={setSize} />
          <div className="space-y-2">
            <Label htmlFor="qty">Pairs</Label>
            <Input
              id="qty"
              type="number"
              min={1}
              max={6}
              value={qty}
              onChange={(e) => setQty(Number(e.target.value) || 1)}
            />
          </div>
          <DeliveryPick
            kind={delivery}
            custom={customFee}
            rates={rates}
            onKind={setDelivery}
            onCustom={setCustomFee}
          />
          {delivery !== "collect" ? (
            <div className="space-y-2">
              <Label htmlFor="address">Address</Label>
              <Input
                id="address"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="Where we send the pair"
              />
            </div>
          ) : null}
          <div className="space-y-2">
            <Label htmlFor="name">Your name</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              autoComplete="name"
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="phone">WhatsApp number</Label>
            <Input
              id="phone"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              inputMode="tel"
              autoComplete="tel"
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="note">Note</Label>
            <Input
              id="note"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Optional"
            />
          </div>
          {error ? <p className="text-sm text-primary">{error}</p> : null}
          <Button type="submit" size="lg" className="w-full sm:w-auto" disabled={busy}>
            {busy ? "Sending…" : "Send the order"}
          </Button>
        </form>
      </div>

      <aside className="min-w-0">
        <div className="overflow-hidden rounded-[var(--radius-xl)] bg-elevated">
          <img
            src={product.image}
            alt={`${product.sku} ${product.look}`}
            className="aspect-[4/3] w-full object-cover"
          />
        </div>
        <div className="mt-5 rounded-[var(--radius-lg)] border border-border bg-elevated p-5">
          <p className="text-xs tracking-[0.16em] uppercase text-muted">This request</p>
          <p className="font-display mt-2 text-3xl tabular-nums">{product.sku}</p>
          <p className="mt-1 text-sm">{product.look}</p>
          <p className="mt-4 text-sm leading-relaxed text-muted">{summary}</p>
          <div className="mt-6 flex items-baseline justify-between border-t border-border pt-4">
            <span className="text-xs tracking-[0.14em] uppercase text-muted">Listed</span>
            <span className="font-display text-2xl tabular-nums">{zar(total)}</span>
          </div>
          <p className="mt-3 text-xs leading-relaxed text-subtle">
            Pair {zar(product.price)}
            {qty > 1 ? ` × ${qty}` : ""}
            {fee ? ` · ${DELIVERY_LABEL[delivery]} ${zar(fee)}` : " · collect, no fee"}. We
            do not take payment until the bench confirms the pair.
          </p>
        </div>
      </aside>
    </main>
  );
}
