import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useSable } from "@/lib/store";
import { atLeast } from "@/lib/access";
import { ChipRow, chipClass } from "@/components/chip-row";
import { DeskGate, GatePending } from "@/components/desk-gate";
import { useLiveNotes, useLiveProducts } from "@/lib/live";
import { Button } from "@/components/ui/button";
import { Input, Label } from "@/components/ui/input";
import { MEMORY } from "@/lib/memory";
import { PRODUCTS } from "@/lib/catalogue";
import type { HouseCopy } from "@/lib/copy";

export const Route = createFileRoute("/build")({ component: BuildPage });

const PAGE = 20;
type Tab = "catalogue" | "pages" | "delivery" | "invoice" | "memory";

function BuildPage() {
  const hydrated = useSable((s) => s.hydrated);
  const role = useSable((s) => s.deskRole);
  const products = useLiveProducts();
  const notes = useLiveNotes();
  const setPrice = useSable((s) => s.setPrice);
  const setLook = useSable((s) => s.setLook);
  const setNoteBody = useSable((s) => s.setNoteBody);
  const addNote = useSable((s) => s.addNote);
  const copy = useSable((s) => s.copy);
  const setCopy = useSable((s) => s.setCopy);
  const featured = useSable((s) => s.featured);
  const setFeatured = useSable((s) => s.setFeatured);
  const resetOverrides = useSable((s) => s.resetOverrides);
  const delivery = useSable((s) => s.delivery);
  const setDelivery = useSable((s) => s.setDelivery);
  const [q, setQ] = useState("");
  const [page, setPage] = useState(0);
  const [tab, setTab] = useState<Tab>("catalogue");
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [slug, setSlug] = useState("brand");

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return products;
    return products.filter(
      (p) =>
        p.sku.toLowerCase().includes(s) ||
        p.look.toLowerCase().includes(s) ||
        p.type.toLowerCase().includes(s) ||
        String(p.n) === s,
    );
  }, [q, products]);

  const pages = Math.max(1, Math.ceil(filtered.length / PAGE));
  const safePage = Math.min(page, pages - 1);
  const rows = filtered.slice(safePage * PAGE, safePage * PAGE + PAGE);

  if (!hydrated) return <GatePending />;
  if (!atLeast(role, "manager")) return <DeskGate need="manager" />;

  const active = notes.find((n) => n.slug === slug) ?? notes[0];

  function download() {
    const md = notes.map((n) => `# ${n.title}\n\n${n.body}\n`).join("\n---\n\n");
    const blob = new Blob([md], { type: "text/markdown" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "sable-house.md";
    a.click();
  }

  return (
    <main className="mx-auto max-w-6xl px-4 py-8 sm:px-6 sm:py-10">
      <p className="text-xs tracking-[0.24em] uppercase text-muted">Manager</p>
      <h1 className="font-display mt-2 text-4xl">Build</h1>
      <p className="mt-3 max-w-2xl text-sm text-muted">
        Change the public page, prices, names, delivery fees, invoices, and memory.
        Manager and admin. Does not spend Grok usage.
      </p>

      <div className="mt-8 flex flex-col gap-3 md:flex-row md:items-center">
        <ChipRow className="flex-1">
          {(
            [
              ["catalogue", "Catalogue"],
              ["pages", "Site"],
              ["delivery", "Delivery"],
              ["invoice", "Invoice"],
              ["memory", "Memory"],
            ] as const
          ).map(([id, label]) => (
            <button key={id} type="button" onClick={() => setTab(id)} className={chipClass(tab === id)}>
              {label}
            </button>
          ))}
        </ChipRow>
        <Button type="button" variant="outline" className="w-full md:ml-auto md:w-auto" onClick={resetOverrides}>
          Reset house
        </Button>
      </div>

      {tab === "catalogue" ? (
        <section className="mt-10">
          <div className="flex flex-col gap-4 sm:flex-row sm:flex-wrap sm:items-end sm:justify-between">
            <h2 className="font-display text-3xl">Catalogue</h2>
            <Input
              value={q}
              onChange={(e) => {
                setQ(e.target.value);
                setPage(0);
              }}
              placeholder="Search 45004 or vellie"
              className="w-full sm:max-w-xs"
            />
          </div>
          <div className="mt-4 space-y-3 md:hidden">
            {rows.map((p) => (
              <article
                key={p.sku}
                className="space-y-3 rounded-[var(--radius-lg)] border border-border bg-elevated p-3"
              >
                <div className="flex items-baseline justify-between gap-3">
                  <p className="font-display text-xl tabular-nums">{p.sku}</p>
                  <p className="text-xs uppercase tracking-wider text-muted">{p.category}</p>
                </div>
                <div className="space-y-1">
                  <Label htmlFor={`look-${p.sku}`}>Type</Label>
                  <input
                    id={`look-${p.sku}`}
                    className="h-11 w-full rounded-[var(--radius-sm)] border border-border bg-bg px-3 text-fg"
                    value={p.look}
                    onChange={(e) => setLook(p.sku, e.target.value)}
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <Label htmlFor={`price-${p.sku}`}>Listed</Label>
                    <input
                      id={`price-${p.sku}`}
                      className="h-11 w-full rounded-[var(--radius-sm)] border border-border bg-bg px-3 tabular-nums text-fg"
                      defaultValue={p.price ?? ""}
                      key={`${p.sku}-${p.price ?? "poa"}-m`}
                      onBlur={(e) => {
                        const raw = e.target.value.trim();
                        if (raw === "") setPrice(p.sku, null);
                        else {
                          const n = Number(raw);
                          if (!Number.isNaN(n)) setPrice(p.sku, n);
                        }
                      }}
                    />
                  </div>
                  <div className="space-y-1">
                    <Label>Cost</Label>
                    <p className="flex h-11 items-center text-sm tabular-nums text-subtle">{p.cost}</p>
                  </div>
                </div>
              </article>
            ))}
          </div>
          <div className="mt-4 hidden overflow-x-auto rounded-[var(--radius-lg)] border border-border md:block">
            <table className="w-full min-w-[640px] text-left text-sm">
              <thead className="bg-elevated text-xs tracking-[0.14em] uppercase text-muted">
                <tr>
                  <th className="px-3 py-3 font-medium">Stock</th>
                  <th className="px-3 py-3 font-medium">Type</th>
                  <th className="px-3 py-3 font-medium">Band</th>
                  <th className="px-3 py-3 font-medium">Listed</th>
                  <th className="px-3 py-3 font-medium">Cost</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((p) => (
                  <tr key={p.sku} className="border-t border-border">
                    <td className="px-3 py-2 tabular-nums text-muted">{p.sku}</td>
                    <td className="px-3 py-2">
                      <input
                        className="h-10 w-full rounded-[var(--radius-sm)] border border-border bg-elevated px-2 text-fg"
                        value={p.look}
                        onChange={(e) => setLook(p.sku, e.target.value)}
                      />
                    </td>
                    <td className="px-3 py-2 text-muted">{p.category}</td>
                    <td className="px-3 py-2">
                      <input
                        className="h-10 w-28 rounded-[var(--radius-sm)] border border-border bg-elevated px-2 tabular-nums text-fg"
                        defaultValue={p.price ?? ""}
                        key={`${p.sku}-${p.price ?? "poa"}`}
                        onBlur={(e) => {
                          const raw = e.target.value.trim();
                          if (raw === "") setPrice(p.sku, null);
                          else {
                            const n = Number(raw);
                            if (!Number.isNaN(n)) setPrice(p.sku, n);
                          }
                        }}
                      />
                    </td>
                    <td className="px-3 py-2 tabular-nums text-subtle">{p.cost}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="mt-3 flex flex-wrap items-center justify-between gap-3 text-xs text-subtle">
            <p>
              Showing {rows.length ? safePage * PAGE + 1 : 0}–{safePage * PAGE + rows.length} of{" "}
              {filtered.length}. Listed rand saves when you leave the field.
            </p>
            <div className="flex w-full gap-2 sm:w-auto">
              <Button
                type="button"
                variant="outline"
                className="flex-1 sm:flex-none"
                disabled={safePage <= 0}
                onClick={() => setPage((n) => Math.max(0, n - 1))}
              >
                Previous
              </Button>
              <Button
                type="button"
                variant="outline"
                className="flex-1 sm:flex-none"
                disabled={safePage >= pages - 1}
                onClick={() => setPage((n) => n + 1)}
              >
                Next
              </Button>
            </div>
          </div>
        </section>
      ) : null}

      {tab === "pages" ? (
        <section className="mt-10 grid gap-8 lg:grid-cols-2">
          <div className="space-y-4">
            <h2 className="font-display text-3xl">House page</h2>
            {(
              [
                ["kicker", "Kicker", copy.kicker],
                ["title", "Title", copy.title],
                ["blurb", "Blurb", copy.blurb],
                ["whyTitle", "Why heading", copy.whyTitle],
                ["why", "Why to buy", copy.why],
                ["storyTitle", "Story heading", copy.storyTitle],
                ["story", "Story", copy.story],
                ["shareLine", "Share line", copy.shareLine],
              ] as const
            ).map(([field, label, value]) => (
              <CopyField
                key={field}
                id={field}
                label={label}
                value={value}
                rows={field === "kicker" || field === "whyTitle" || field === "storyTitle" ? 1 : 4}
                onSave={(v) => setCopy({ [field]: v } as Partial<HouseCopy>)}
              />
            ))}
            <h2 className="font-display pt-4 text-3xl">Factory</h2>
            <CopyField
              id="factoryTitle"
              label="Title"
              value={copy.factoryTitle}
              rows={1}
              onSave={(v) => setCopy({ factoryTitle: v })}
            />
            <CopyField
              id="factoryLead"
              label="Lead"
              value={copy.factoryLead}
              rows={1}
              onSave={(v) => setCopy({ factoryLead: v })}
            />
            <CopyField
              id="factoryBody"
              label="Body"
              value={copy.factoryBody}
              rows={6}
              onSave={(v) => setCopy({ factoryBody: v })}
            />
          </div>
          <div>
            <h2 className="font-display text-3xl">Selected pairs</h2>
            <p className="mt-2 text-sm text-muted">Up to six on the house page.</p>
            <div className="mt-4 grid gap-3">
              {[0, 1, 2, 3, 4, 5].map((i) => (
                <select
                  key={i}
                  className="flex h-11 w-full rounded-[var(--radius-sm)] border border-border bg-elevated px-3 text-sm text-fg"
                  value={featured[i] ?? ""}
                  onChange={(e) => {
                    const next = [...featured];
                    next[i] = Number(e.target.value);
                    setFeatured(next);
                  }}
                >
                  <option value="">None</option>
                  {PRODUCTS.map((p) => (
                    <option key={p.sku} value={p.n}>
                      {p.sku} · {p.look}
                    </option>
                  ))}
                </select>
              ))}
            </div>
          </div>
        </section>
      ) : null}

      {tab === "delivery" ? (
        <section className="mt-10 max-w-lg space-y-4">
          <h2 className="font-display text-3xl">Delivery fees</h2>
          <p className="text-sm text-muted">
            Defaults: local R100, international R300. Change the numbers. Each order can
            still pick collect, local, international, or a custom fee.
          </p>
          <div className="space-y-2">
            <Label htmlFor="local">Local (ZAR)</Label>
            <Input
              id="local"
              type="number"
              min={0}
              value={delivery.local}
              onChange={(e) => setDelivery({ local: Number(e.target.value) || 0 })}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="intl">International (ZAR)</Label>
            <Input
              id="intl"
              type="number"
              min={0}
              value={delivery.international}
              onChange={(e) => setDelivery({ international: Number(e.target.value) || 0 })}
            />
          </div>
          <CopyField
            id="deliveryNote"
            label="Public note"
            value={copy.deliveryNote}
            rows={3}
            onSave={(v) => setCopy({ deliveryNote: v })}
          />
        </section>
      ) : null}

      {tab === "invoice" ? (
        <section className="mt-10 max-w-lg space-y-4">
          <h2 className="font-display text-3xl">Invoice wording</h2>
          <p className="text-sm text-muted">
            This is what prints on the phone invoice. Change any of it.
          </p>
          <CopyField
            id="invoiceFrom"
            label="From"
            value={copy.invoiceFrom}
            rows={4}
            onSave={(v) => setCopy({ invoiceFrom: v })}
          />
          <CopyField
            id="invoicePay"
            label="How to pay"
            value={copy.invoicePay}
            rows={3}
            onSave={(v) => setCopy({ invoicePay: v })}
          />
          <CopyField
            id="invoiceNote"
            label="Footer"
            value={copy.invoiceNote}
            rows={2}
            onSave={(v) => setCopy({ invoiceNote: v })}
          />
        </section>
      ) : null}

      {tab === "memory" ? (
        <section className="mt-10 grid gap-6 lg:grid-cols-2">
          <div>
            <h2 className="font-display text-3xl">Memory</h2>
            <div className="mt-4 space-y-2">
              <Label htmlFor="file">File</Label>
              <select
                id="file"
                className="flex h-11 w-full rounded-[var(--radius-sm)] border border-border bg-elevated px-3 text-sm text-fg"
                value={active?.slug}
                onChange={(e) => setSlug(e.target.value)}
              >
                {notes.map((n) => (
                  <option key={n.slug} value={n.slug}>
                    {n.title}
                  </option>
                ))}
              </select>
              <textarea
                key={active?.slug}
                className="mt-2 min-h-48 w-full rounded-[var(--radius-md)] border border-border bg-elevated p-3 text-sm leading-relaxed text-fg"
                defaultValue={active?.body}
                onBlur={(e) => {
                  if (active) setNoteBody(active.slug, e.target.value);
                }}
              />
              <p className="text-xs text-subtle">Saves when you leave the field.</p>
            </div>
          </div>
          <div>
            <h2 className="font-display text-3xl">New file</h2>
            <div className="mt-4 space-y-3">
              <Label htmlFor="title">Title</Label>
              <Input id="title" value={title} onChange={(e) => setTitle(e.target.value)} />
              <Label htmlFor="body">Body</Label>
              <textarea
                id="body"
                className="min-h-32 w-full rounded-[var(--radius-md)] border border-border bg-elevated p-3 text-sm text-fg"
                value={body}
                onChange={(e) => setBody(e.target.value)}
              />
              <Button
                type="button"
                disabled={!title.trim() || !body.trim()}
                onClick={() => {
                  addNote({
                    slug: `custom-${title.toLowerCase().replace(/[^a-z0-9]+/g, "-")}-${Date.now().toString(36)}`,
                    title: title.trim(),
                    tag: "Build",
                    minRole: "manager",
                    body: body.trim(),
                  });
                  setTitle("");
                  setBody("");
                }}
              >
                File it
              </Button>
              <Button type="button" variant="outline" onClick={download}>
                Download house markdown
              </Button>
              <p className="text-xs text-subtle">
                {MEMORY.length} core files. Custom files stay on this device until you
                download and drop them into Obsidian.
              </p>
            </div>
          </div>
        </section>
      ) : null}
    </main>
  );
}

function CopyField({
  id,
  label,
  value,
  rows,
  onSave,
}: {
  id: string;
  label: string;
  value: string;
  rows: number;
  onSave: (v: string) => void;
}) {
  return (
    <div className="space-y-2">
      <Label htmlFor={id}>{label}</Label>
      {rows <= 1 ? (
        <Input id={id} value={value} onChange={(e) => onSave(e.target.value)} />
      ) : (
        <textarea
          id={id}
          rows={rows}
          value={value}
          onChange={(e) => onSave(e.target.value)}
          className="w-full rounded-[var(--radius-md)] border border-border bg-elevated p-3 text-sm leading-relaxed text-fg"
        />
      )}
    </div>
  );
}
