import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { SIZE_ROWS } from "@/lib/sizes";

export const Route = createFileRoute("/sizes")({ component: SizesPage });

function SizesPage() {
  return (
    <main className="mx-auto max-w-3xl px-4 py-8 sm:px-6 sm:py-10">
      <p className="text-xs tracking-[0.24em] uppercase text-muted">Fit</p>
      <h1 className="font-display mt-2 text-4xl sm:text-5xl">Size guide</h1>
      <p className="mt-4 max-w-lg text-sm leading-relaxed text-muted">
        UK / South African sizing. Measure standing, heel to the longest toe. If
        you are between sizes, go up — the leather eases.
      </p>

      <div className="mt-10 overflow-x-auto rounded-[var(--radius-lg)] border border-border">
        <table className="w-full min-w-[20rem] text-left text-sm">
          <thead className="bg-elevated text-xs tracking-[0.14em] uppercase text-muted">
            <tr>
              <th className="px-4 py-3 font-medium">UK / SA</th>
              <th className="px-4 py-3 font-medium">EU</th>
              <th className="px-4 py-3 font-medium">Foot (cm)</th>
            </tr>
          </thead>
          <tbody>
            {SIZE_ROWS.map((row) => (
              <tr key={row.uk} className="border-t border-border">
                <td className="px-4 py-3 tabular-nums">{row.uk}</td>
                <td className="px-4 py-3 tabular-nums text-muted">{row.eu}</td>
                <td className="px-4 py-3 tabular-nums text-muted">{row.cm}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <ol className="mt-10 space-y-4 text-sm leading-relaxed text-muted">
        <li>
          <span className="text-fg">Heel to a wall.</span> Mark the longest toe.
          Measure that line in centimetres.
        </li>
        <li>
          <span className="text-fg">Match the table.</span> Kids often sit 3–6.
          Most adults sit 7–11.
        </li>
        <li>
          <span className="text-fg">Still unsure.</span> WhatsApp the 45xxx and
          the centimetre. We confirm the last before we send the pair.
        </li>
      </ol>

      <div className="mt-10 flex flex-col gap-3 sm:flex-row">
        <Button asChild size="lg" className="w-full sm:w-auto">
          <Link to="/enquire">WhatsApp a pair</Link>
        </Button>
        <Button asChild variant="outline" size="lg" className="w-full sm:w-auto">
          <Link to="/collection">See the book</Link>
        </Button>
      </div>
    </main>
  );
}
