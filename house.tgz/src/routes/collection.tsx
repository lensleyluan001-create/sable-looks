import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { ChipRow, chipClass } from "@/components/chip-row";
import { FILTERS, matchesFilter, type Filter } from "@/lib/catalogue";
import { zar } from "@/lib/utils";
import { useSable } from "@/lib/store";
import { useLiveProducts } from "@/lib/live";
import { Input } from "@/components/ui/input";

export const Route = createFileRoute("/collection")({ component: Collection });

function Collection() {
  const [cat, setCat] = useState<Filter>("All");
  const [q, setQ] = useState("");
  const saved = useSable((s) => s.saved);
  const products = useLiveProducts();
  const list = useMemo(() => {
    const s = q.trim().toLowerCase();
    return products.filter((p) => {
      if (!matchesFilter(p, cat)) return false;
      if (!s) return true;
      return (
        p.sku.includes(s) ||
        p.look.toLowerCase().includes(s) ||
        p.type.toLowerCase().includes(s) ||
        String(p.n) === s
      );
    });
  }, [cat, products, q]);

  return (
    <main className="mx-auto max-w-6xl px-4 py-8 sm:px-6 sm:py-10">
      <p className="text-xs tracking-[0.24em] uppercase text-muted">2026 lookbook</p>
      <h1 className="font-display mt-2 text-4xl sm:text-5xl">Collection</h1>
      <p className="mt-3 max-w-xl text-sm text-muted">
        Track every pair as 45001–45092. The name is the type. Listed ZAR, subject to
        availability.
      </p>
      <ChipRow className="mt-8" edge>
        {FILTERS.map((c) => (
          <button key={c} type="button" onClick={() => setCat(c)} className={chipClass(cat === c)}>
            {c}
          </button>
        ))}
      </ChipRow>
      <div className="mt-4 w-full max-w-xs">
        <Input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search 45004, vellie…"
        />
      </div>
      <p className="mt-4 text-xs text-subtle">{list.length} pairs</p>
      <div className="mt-6 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {list.map((p) => (
          <Link
            key={p.sku}
            to="/product/$sku"
            params={{ sku: p.sku }}
            className="group block"
          >
            <div className="relative overflow-hidden rounded-[var(--radius-lg)] bg-elevated">
              <img
                src={p.image}
                alt={`${p.sku} ${p.look}`}
                className="aspect-[4/3] w-full object-cover transition-transform duration-[var(--motion-fast)] group-hover:scale-[1.03]"
              />
              {saved.includes(p.sku) ? (
                <span className="absolute right-3 top-3 rounded-full bg-paper px-2 py-1 text-[10px] tracking-[0.14em] uppercase text-ink">
                  Saved
                </span>
              ) : null}
            </div>
            <div className="mt-3 flex items-baseline justify-between gap-3">
              <h2 className="font-display text-2xl tabular-nums">{p.sku}</h2>
              <span className="text-sm tabular-nums">{zar(p.price)}</span>
            </div>
            <p className="text-xs tracking-[0.12em] uppercase text-muted">
              {p.look} · Item {String(p.n).padStart(2, "0")}
            </p>
          </Link>
        ))}
      </div>
    </main>
  );
}
