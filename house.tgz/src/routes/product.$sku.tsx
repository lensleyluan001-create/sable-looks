import { useState } from "react";
import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { ShareBar } from "@/components/share-bar";
import { SizePick } from "@/components/size-pick";
import { liveBySku, useLiveProducts } from "@/lib/live";
import { useSable } from "@/lib/store";
import { zar } from "@/lib/utils";

export const Route = createFileRoute("/product/$sku")({
  component: ProductPage,
});

function ProductPage() {
  const { sku } = Route.useParams();
  const products = useLiveProducts();
  const product = liveBySku(products, sku);
  if (!product) throw notFound();
  const saved = useSable((s) => s.saved.includes(product.sku));
  const toggle = useSable((s) => s.toggleSaved);
  const delivery = useSable((s) => s.delivery);
  const [size, setSize] = useState("");
  const related = products
    .filter((p) => p.type === product.type && p.sku !== product.sku)
    .slice(0, 3);

  return (
    <main className="mx-auto grid max-w-6xl gap-8 px-4 py-8 sm:grid-cols-2 sm:gap-10 sm:px-6 sm:py-10">
      <div className="overflow-hidden rounded-[var(--radius-xl)] bg-elevated">
        <img
          src={product.image}
          alt={`${product.sku} ${product.look}`}
          className="aspect-[4/3] w-full object-cover"
        />
      </div>
      <div className="flex flex-col justify-center">
        <p className="text-xs tracking-[0.22em] uppercase text-muted">
          {product.look} · Item {String(product.n).padStart(2, "0")}
        </p>
        <h1 className="font-display mt-2 text-4xl tabular-nums sm:text-5xl">{product.sku}</h1>
        <p className="mt-1 font-display text-2xl">{product.look}</p>
        <p className="mt-2 font-display text-3xl tabular-nums">{zar(product.price)}</p>
        <p className="mt-4 max-w-md text-sm leading-relaxed text-muted">{product.blurb}</p>
        <p className="mt-4 text-xs text-subtle">
          Track as {product.sku}. Listed price. Subject to availability. Local delivery{" "}
          {zar(delivery.local)}. International {zar(delivery.international)}.
        </p>
        <div className="mt-8">
          <SizePick value={size} onChange={setSize} />
        </div>
        <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:flex-wrap">
          <Button asChild size="lg" className="w-full sm:w-auto">
            <Link to="/enquire" search={{ sku: product.sku, size: size || undefined }}>
              {size ? `Enquire UK ${size}` : "Enquire"}
            </Link>
          </Button>
          <Button
            type="button"
            variant="outline"
            size="lg"
            className="w-full sm:w-auto"
            onClick={() => toggle(product.sku)}
          >
            {saved ? "Saved" : "Save"}
          </Button>
        </div>
        <div className="mt-6">
          <ShareBar path={`/product/${product.sku}`} compact />
        </div>
        <div className="mt-12">
          <p className="text-xs tracking-[0.16em] uppercase text-muted">Same type</p>
          <div className="mt-3 flex gap-3">
            {related.map((p) => (
              <Link
                key={p.sku}
                to="/product/$sku"
                params={{ sku: p.sku }}
                className="block w-24"
              >
                <img
                  src={p.image}
                  alt={p.sku}
                  className="aspect-square w-full rounded-[var(--radius-md)] object-cover"
                />
                <p className="mt-1 truncate text-xs tabular-nums text-muted">{p.sku}</p>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </main>
  );
}
