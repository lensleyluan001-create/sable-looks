import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { ShareBar } from "@/components/share-bar";
import { housePhoto } from "@/lib/catalogue";
import { useLiveFeatured, useLiveProducts } from "@/lib/live";
import { useSable } from "@/lib/store";
import { zar } from "@/lib/utils";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const products = useLiveProducts();
  const featured = useLiveFeatured();
  const copy = useSable((s) => s.copy);
  const delivery = useSable((s) => s.delivery);
  const priced = products.map((p) => p.price);
  const min = priced.length ? Math.min(...priced) : 0;
  const golfers = products.filter((p) => p.type === "Golfer").length;
  const hero = products.find((p) => p.sku === "45015") ?? products[0];
  const reasons = copy.why
    .split(/\n\n+/)
    .map((p) => p.trim())
    .filter(Boolean);

  return (
    <main>
      <section className="relative min-h-[78vh] overflow-hidden">
        <img
          src={hero?.image ?? housePhoto("45015")}
          alt="Sable leather chelsea 45015"
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-bg via-bg/60 to-bg/15" />
        <div className="relative mx-auto flex min-h-[70dvh] max-w-6xl flex-col justify-end gap-5 px-4 py-12 sm:min-h-[78vh] sm:px-6 sm:py-16">
          <p className="text-xs tracking-[0.28em] uppercase text-primary">{copy.kicker}</p>
          <h1 className="font-display max-w-xl whitespace-pre-line text-4xl leading-[0.95] tracking-tight sm:text-7xl">
            {copy.title}
          </h1>
          <p className="max-w-md text-sm leading-relaxed text-fg/85">{copy.blurb}</p>
          <div className="flex flex-col gap-3 sm:flex-row sm:flex-wrap">
            <Button asChild size="lg" className="w-full sm:w-auto">
              <Link to="/collection">See the 2026 book</Link>
            </Button>
            <Button asChild variant="outline" size="lg" className="w-full sm:w-auto">
              <Link to="/enquire">WhatsApp a pair</Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="mx-auto grid max-w-6xl grid-cols-2 gap-px border-y border-border bg-border sm:grid-cols-4">
        {[
          [String(products.length), "Pairs in the book"],
          [String(golfers), "Golfers"],
          [zar(min), "From"],
          ["45xxx", "Stock numbers"],
        ].map(([v, k]) => (
          <div key={k} className="bg-bg px-3 py-6 sm:px-4 sm:py-8">
            <p className="font-display text-2xl text-fg sm:text-3xl">{v}</p>
            <p className="mt-1 text-[10px] tracking-[0.16em] uppercase text-muted sm:text-xs">{k}</p>
          </div>
        ))}
      </section>

      <section className="mx-auto max-w-6xl px-4 py-12 sm:px-6 sm:py-16">
        <p className="text-xs tracking-[0.24em] uppercase text-muted">The point</p>
        <h2 className="font-display mt-2 max-w-lg text-3xl sm:text-5xl">{copy.whyTitle}</h2>
        <div className="mt-10 grid gap-8 md:grid-cols-3">
          {reasons.slice(0, 3).map((block, i) => (
            <article key={i} className="border-t border-border pt-5">
              <p className="text-xs tabular-nums text-subtle">{String(i + 1).padStart(2, "0")}</p>
              <p className="mt-3 text-sm leading-relaxed text-fg/90">{block}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 pb-16 sm:px-6">
        <div className="mb-8 flex items-end justify-between gap-4">
          <h2 className="font-display text-3xl">From the bench</h2>
          <Link
            to="/collection"
            className="text-xs tracking-[0.16em] uppercase text-muted hover:text-fg"
          >
            All 92
          </Link>
        </div>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {featured.map((p) => (
            <Link key={p.sku} to="/product/$sku" params={{ sku: p.sku }} className="group block">
              <div className="overflow-hidden rounded-[var(--radius-lg)] bg-elevated">
                <img
                  src={p.image}
                  alt={`${p.sku} ${p.look}`}
                  className="aspect-[4/3] w-full object-cover transition-transform duration-[var(--motion-fast)] group-hover:scale-[1.03]"
                />
              </div>
              <div className="mt-3 flex items-baseline justify-between gap-2">
                <p className="font-display text-xl tabular-nums">{p.sku}</p>
                <p className="text-sm tabular-nums text-muted">{zar(p.price)}</p>
              </div>
              <p className="text-xs tracking-[0.12em] uppercase text-subtle">{p.look}</p>
            </Link>
          ))}
        </div>
      </section>

      <section className="border-y border-border bg-elevated">
        <div className="mx-auto grid max-w-6xl gap-10 px-4 py-16 sm:grid-cols-2 sm:px-6">
          <div>
            <p className="text-xs tracking-[0.24em] uppercase text-muted">House</p>
            <h2 className="font-display mt-2 text-4xl">{copy.storyTitle}</h2>
            <p className="mt-4 max-w-md text-sm leading-relaxed text-muted">{copy.story}</p>
          </div>
          <div>
            <p className="text-xs tracking-[0.24em] uppercase text-muted">Send a pair</p>
            <h2 className="font-display mt-2 text-4xl">Delivery</h2>
            <ul className="mt-6 space-y-4 text-sm">
              <li className="flex items-baseline justify-between gap-4 border-b border-border pb-3">
                <span>Collect</span>
                <span className="tabular-nums text-muted">No fee</span>
              </li>
              <li className="flex items-baseline justify-between gap-4 border-b border-border pb-3">
                <span>Local</span>
                <span className="tabular-nums text-muted">{zar(delivery.local)}</span>
              </li>
              <li className="flex items-baseline justify-between gap-4 border-b border-border pb-3">
                <span>International</span>
                <span className="tabular-nums text-muted">{zar(delivery.international)}</span>
              </li>
            </ul>
            <p className="mt-4 text-xs leading-relaxed text-subtle">{copy.deliveryNote}</p>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
        <p className="text-xs tracking-[0.24em] uppercase text-muted">Pass it on</p>
        <h2 className="font-display mt-2 max-w-lg text-4xl">Send this page</h2>
        <p className="mt-3 max-w-md text-sm text-muted">
          WhatsApp, X, or a copied link. The 45xxx and the listed rand travel with it.
        </p>
        <div className="mt-8">
          <ShareBar />
        </div>
        <p className="mt-6 max-w-md text-xs text-subtle">{copy.shareLine}</p>
      </section>
    </main>
  );
}
