import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo } from "react";
import { Button } from "@/components/ui/button";
import { SalesChart } from "@/components/sales-chart";
import { atLeast } from "@/lib/access";
import { STAGE_LABEL, STAGES, type Stage } from "@/lib/floor";
import { liveBySku, useLiveProducts } from "@/lib/live";
import { invoiceTotal } from "@/lib/money";
import { useSable } from "@/lib/store";
import { cn, zar } from "@/lib/utils";

export const Route = createFileRoute("/floor")({ component: FloorPage });

function FloorPage() {
  const leads = useSable((s) => s.leads);
  const invoices = useSable((s) => s.invoices);
  const moveLead = useSable((s) => s.moveLead);
  const role = useSable((s) => s.deskRole);
  const products = useLiveProducts();
  const showCost = atLeast(role, "manager");

  const counts = useMemo(() => {
    const open = leads.filter((l) => l.status !== "closed" && l.status !== "lost");
    const paid = invoices.filter((i) => i.status === "paid");
    const invoiced = invoices.reduce(
      (s, i) => s + invoiceTotal(i.unitPrice, i.qty, i.deliveryFee),
      0,
    );
    const taken = paid.reduce(
      (s, i) => s + invoiceTotal(i.unitPrice, i.qty, i.deliveryFee),
      0,
    );
    const profit = showCost
      ? paid.reduce((s, i) => {
          const shoe = liveBySku(products, i.sku);
          if (!shoe) return s;
          return s + (shoe.price - shoe.cost) * i.qty;
        }, 0)
      : 0;
    return {
      open: open.length,
      newToday: leads.filter((l) => l.status === "new").length,
      closed: leads.filter((l) => l.status === "closed").length,
      invoices: invoices.length,
      invoiced,
      taken,
      profit,
    };
  }, [leads, invoices, products, showCost]);

  return (
    <main className="mx-auto max-w-[1400px] px-4 py-8 sm:px-6 sm:py-10">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-xs tracking-[0.24em] uppercase text-muted">Sales board</p>
          <h1 className="font-display mt-2 text-4xl">Floor</h1>
          <p className="mt-3 max-w-xl text-sm text-muted">
            People, pairs, invoices. Track the 45xxx. WhatsApp first.
          </p>
        </div>
        <Button asChild size="lg" className="w-full sm:w-auto">
          <Link to="/capture">Capture lead</Link>
        </Button>
      </div>

      <section className="mt-8 grid grid-cols-2 gap-px border border-border bg-border sm:grid-cols-3 lg:grid-cols-6">
        {[
          [String(counts.open), "Open"],
          [String(counts.newToday), "New"],
          [String(counts.closed), "Closed"],
          [String(counts.invoices), "Invoices"],
          [zar(counts.taken), "Paid"],
          showCost ? [zar(counts.profit), "On the pair"] : [zar(counts.invoiced), "Invoiced"],
        ].map(([v, k]) => (
          <div key={k} className="bg-bg px-3 py-5 sm:px-4 sm:py-6">
            <p className="font-display text-xl tabular-nums sm:text-3xl">{v}</p>
            <p className="mt-1 text-[10px] tracking-[0.16em] uppercase text-muted sm:text-xs">{k}</p>
          </div>
        ))}
      </section>

      <section className="mt-8">
        <div className="mb-3 flex items-end justify-between gap-3">
          <h2 className="font-display text-2xl">Fourteen days</h2>
          <p className="text-xs text-subtle">Invoiced vs paid</p>
        </div>
        <SalesChart invoices={invoices} />
      </section>

      {invoices.length > 0 ? (
        <section className="mt-10">
          <h2 className="font-display text-2xl">Invoices</h2>
          <ul className="mt-4 divide-y divide-border rounded-[var(--radius-lg)] border border-border">
            {invoices.slice(0, 12).map((inv) => (
              <li key={inv.id}>
                <Link
                  to="/invoices/$id"
                  params={{ id: inv.id }}
                  className="flex min-h-14 items-center justify-between gap-3 px-4 py-3 hover:bg-elevated"
                >
                  <div className="min-w-0">
                    <p className="truncate text-sm">
                      {inv.number} · {inv.name}
                    </p>
                    <p className="text-xs text-muted">
                      {inv.sku} · {inv.look} · {inv.status}
                    </p>
                  </div>
                  <p className="shrink-0 text-sm tabular-nums">
                    {zar(invoiceTotal(inv.unitPrice, inv.qty, inv.deliveryFee))}
                  </p>
                </Link>
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      {leads.length === 0 ? (
        <div className="mt-10 rounded-[var(--radius-lg)] border border-border bg-elevated px-6 py-16 text-center">
          <p className="font-display text-3xl">No one on the board yet</p>
          <p className="mx-auto mt-3 max-w-md text-sm text-muted">
            Capture a name, phone, and 45xxx. Raise an invoice when the pair is going.
          </p>
          <Button asChild className="mt-8">
            <Link to="/capture">Capture the first lead</Link>
          </Button>
        </div>
      ) : (
        <div>
          <p className="mt-8 text-xs tracking-[0.16em] uppercase text-subtle md:hidden">
            Swipe the stages
          </p>
          <div className="-mx-4 mt-3 flex min-w-0 snap-x snap-mandatory gap-3 overflow-x-auto px-4 pb-6 [scrollbar-width:thin] md:mx-0 md:mt-8 md:px-0">
            {STAGES.map((stage) => {
              const col = leads.filter((l) => l.status === stage);
              return (
                <section
                  key={stage}
                  className="w-[min(280px,82vw)] shrink-0 snap-start rounded-[var(--radius-lg)] border border-border bg-elevated p-3"
                >
                  <div className="flex items-baseline justify-between px-1 pb-3">
                    <h2 className="text-xs tracking-[0.16em] uppercase text-muted">
                      {STAGE_LABEL[stage]}
                    </h2>
                    <span className="text-xs tabular-nums text-subtle">{col.length}</span>
                  </div>
                  <ul className="space-y-2">
                    {col.map((lead) => {
                      const shoe = liveBySku(products, lead.sku);
                      return (
                        <li key={lead.id}>
                          <Link
                            to="/leads/$id"
                            params={{ id: lead.id }}
                            className="block rounded-[var(--radius-md)] border border-border bg-bg p-3 hover:border-primary"
                          >
                            <p className="truncate text-sm font-medium">{lead.name || "No name"}</p>
                            <p className="mt-1 text-xs tabular-nums text-muted">
                              {lead.sku} · {lead.look}
                            </p>
                            <p className="mt-1 text-xs tabular-nums text-subtle">
                              {zar(shoe?.price ?? null)}
                              {lead.size ? ` · UK ${lead.size}` : ""}
                              {showCost && shoe ? ` · cost ${zar(shoe.cost)}` : ""}
                            </p>
                          </Link>
                          <div className="mt-1 flex gap-1">
                            {nextStages(stage).map((n) => (
                              <button
                                key={n}
                                type="button"
                                onClick={() => moveLead(lead.id, n)}
                                className={cn(
                                  "h-11 flex-1 rounded-[var(--radius-xs)] border border-border text-xs tracking-[0.08em] uppercase text-muted hover:text-fg",
                                )}
                              >
                                {STAGE_LABEL[n]}
                              </button>
                            ))}
                          </div>
                        </li>
                      );
                    })}
                  </ul>
                </section>
              );
            })}
          </div>
        </div>
      )}
    </main>
  );
}

function nextStages(stage: Stage): Stage[] {
  if (stage === "new") return ["contacted", "lost"];
  if (stage === "contacted") return ["qualified", "lost"];
  if (stage === "qualified") return ["negotiation", "lost"];
  if (stage === "negotiation") return ["closed", "lost"];
  if (stage === "closed") return [];
  return ["new"];
}
