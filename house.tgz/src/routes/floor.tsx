import { createFileRoute, Link } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { SellerPick } from "@/components/seller-pick";
import { SalesChart } from "@/components/sales-chart";
import { StaffOnly } from "@/components/staff-gate";
import { atLeast } from "@/lib/access";
import { STAGE_LABEL, STAGES, type Stage } from "@/lib/floor";
import { liveBySku, useLiveProducts } from "@/lib/live";
import { invoiceTotal } from "@/lib/money";
import { leadFromOrder, minutesUntilAuto, type HouseOrder } from "@/lib/orders";
import { assignHouseOrder, housePickOrder, listHouseOrders } from "@/lib/house-orders";
import {
  AUTO_ASSIGN_MINUTES,
  SELLER_LABEL,
  pairProfit,
  splitProfit,
  type SellerId,
} from "@/lib/people";
import { useSable } from "@/lib/store";
import { cn, zar } from "@/lib/utils";

export const Route = createFileRoute("/floor")({ component: FloorPage });

function FloorPage() {
  return (
    <StaffOnly>
      <FloorBoard />
    </StaffOnly>
  );
}

function FloorBoard() {
  const leads = useSable((s) => s.leads);
  const invoices = useSable((s) => s.invoices);
  const moveLead = useSable((s) => s.moveLead);
  const upsert = useSable((s) => s.upsertLeadFromOrder);
  const token = useSable((s) => s.deskToken);
  const role = useSable((s) => s.deskRole);
  const products = useLiveProducts();
  const showCost = atLeast(role, "manager");
  const canAssign = atLeast(role, "manager");
  const [orders, setOrders] = useState<HouseOrder[]>([]);
  const [busyId, setBusyId] = useState("");

  const refresh = useCallback(async () => {
    if (!token) return;
    const res = await listHouseOrders({ data: { token } });
    if (!res.ok) return;
    setOrders(res.orders);
    for (const order of res.orders) {
      if (order.assignedTo) upsert(leadFromOrder(order));
    }
  }, [token, upsert]);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  useEffect(() => {
    const t = window.setInterval(() => void refresh(), 20000);
    return () => window.clearInterval(t);
  }, [refresh]);

  async function assign(id: string, seller: SellerId) {
    if (!token) return;
    setBusyId(id);
    const res = await assignHouseOrder({ data: { token, id, seller } });
    setBusyId("");
    if (res.ok && res.order) {
      setOrders((cur) => cur.map((o) => (o.id === res.order?.id ? res.order : o)));
      upsert(leadFromOrder(res.order));
    }
  }

  async function housePick(id: string) {
    if (!token) return;
    setBusyId(id);
    const res = await housePickOrder({ data: { token, id } });
    setBusyId("");
    if (res.ok && res.order) {
      setOrders((cur) => cur.map((o) => (o.id === res.order?.id ? res.order : o)));
      upsert(leadFromOrder(res.order));
    }
  }

  const waiting = orders.filter((o) => !o.assignedTo && o.status === "new");

  const counts = useMemo(() => {
    const open = leads.filter((l) => l.status !== "closed" && l.status !== "lost");
    const paid = invoices.filter((i) => i.status === "paid");
    const invoiced = invoices.reduce(
      (s, i) => s + invoiceTotal(i.unitPrice, i.qty, i.deliveryFee),
      0,
    );
    const taken = paid.reduce(
      (s, i) => s + invoiceTotal(i.unitPrice, i.qty, i.deliveryFee),
      0,
    );
    const profit = showCost
      ? paid.reduce((s, i) => {
          const shoe = liveBySku(products, i.sku);
          if (!shoe) return s;
          return s + pairProfit(shoe.price, shoe.cost, i.qty);
        }, 0)
      : 0;
    return {
      open: open.length,
      newToday: leads.filter((l) => l.status === "new").length,
      closed: leads.filter((l) => l.status === "closed").length,
      invoices: invoices.length,
      invoiced,
      taken,
      profit,
      waiting: waiting.length,
    };
  }, [leads, invoices, products, showCost, waiting.length]);

  const cuts = useMemo(() => {
    if (!showCost) return null;
    const totals = { wian: 0, luan: 0, dylan: 0, house: 0, profit: 0 };
    for (const inv of invoices) {
      if (inv.status !== "paid" || !inv.owner) continue;
      const shoe = liveBySku(products, inv.sku);
      if (!shoe) continue;
      const split = splitProfit(pairProfit(shoe.price, shoe.cost, inv.qty), inv.owner);
      totals.wian += split.wian;
      totals.luan += split.luan;
      totals.dylan += split.dylan;
      totals.house += split.house;
      totals.profit += split.profit;
    }
    return totals;
  }, [invoices, products, showCost]);

  return (
    <main className="mx-auto max-w-[1400px] px-4 py-8 sm:px-6 sm:py-10">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-xs tracking-[0.24em] uppercase text-muted">Sales board</p>
          <h1 className="font-display mt-2 text-4xl">Floor</h1>
          <p className="mt-3 max-w-xl text-sm text-muted">
            Website orders land here. A manager assigns Wian, Luan or Dylan. If nobody
            takes it in {AUTO_ASSIGN_MINUTES} minutes, the house picks.
          </p>
        </div>
        <Button asChild size="lg" className="w-full sm:w-auto">
          <Link to="/capture">Capture lead</Link>
        </Button>
      </div>

      <section className="mt-8 grid grid-cols-2 gap-px border border-border bg-border sm:grid-cols-3 lg:grid-cols-6">
        {[
          [String(counts.waiting), "Website"],
          [String(counts.open), "Open"],
          [String(counts.newToday), "New"],
          [String(counts.closed), "Closed"],
          [zar(counts.taken), "Paid"],
          showCost ? [zar(counts.profit), "On the pair"] : [zar(counts.invoiced), "Invoiced"],
        ].map(([v, k]) => (
          <div key={k} className="bg-bg px-3 py-5 sm:px-4 sm:py-6">
            <p className="font-display text-xl tabular-nums sm:text-3xl">{v}</p>
            <p className="mt-1 text-[10px] tracking-[0.16em] uppercase text-muted sm:text-xs">{k}</p>
          </div>
        ))}
      </section>

      {waiting.length > 0 ? (
        <section className="mt-10">
          <div className="mb-4 flex items-end justify-between gap-3">
            <div>
              <p className="text-xs tracking-[0.16em] uppercase text-muted">Website</p>
              <h2 className="font-display text-2xl">Unassigned deals</h2>
            </div>
            <p className="text-xs text-subtle">
              Auto-assign in {AUTO_ASSIGN_MINUTES} min if the desk is quiet
            </p>
          </div>
          <ul className="space-y-3">
            {waiting.map((order) => {
              const mins = minutesUntilAuto(order.createdAt, AUTO_ASSIGN_MINUTES);
              return (
                <li
                  key={order.id}
                  className="rounded-[var(--radius-lg)] border border-border bg-elevated p-4"
                >
                  <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                    <div className="min-w-0">
                      <p className="font-medium">{order.name}</p>
                      <p className="mt-1 text-sm tabular-nums text-muted">
                        {order.sku} · {order.look} · UK {order.size} · ×{order.qty} ·{" "}
                        {zar(order.unitPrice)}
                      </p>
                      <p className="mt-1 text-xs text-subtle">
                        {order.phone}
                        {mins > 0
                          ? ` · house pick in ${mins} min`
                          : " · due for house pick"}
                      </p>
                    </div>
                    {canAssign ? (
                      <div className="flex min-w-0 flex-col gap-2 sm:items-end">
                        <SellerPick
                          value={null}
                          allowEmpty={false}
                          onChange={(seller) => {
                            if (seller) void assign(order.id, seller);
                          }}
                        />
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          disabled={busyId === order.id}
                          onClick={() => void housePick(order.id)}
                        >
                          House pick
                        </Button>
                      </div>
                    ) : (
                      <p className="text-xs text-subtle">Waiting on a manager</p>
                    )}
                  </div>
                </li>
              );
            })}
          </ul>
        </section>
      ) : (
        <section className="mt-10 rounded-[var(--radius-lg)] border border-border bg-elevated px-5 py-6">
          <p className="text-xs tracking-[0.16em] uppercase text-muted">Website</p>
          <p className="mt-2 text-sm text-muted">
            No open website orders. New ones from sable.co land here first.
          </p>
        </section>
      )}

      {showCost && cuts ? (
        <section className="mt-10">
          <h2 className="font-display text-2xl">Commission on paid pairs</h2>
          <p className="mt-2 max-w-xl text-sm text-muted">
            Split on profit. Wian selling: 20 / 40 / 30 / 10. Luan selling: 60 / 30 /
            10. Dylan selling: 90 / 10. Sales never see this.
          </p>
          <div className="mt-6 grid grid-cols-2 gap-px border border-border bg-border sm:grid-cols-5">
            {(
              [
                [SELLER_LABEL.wian, cuts.wian],
                [SELLER_LABEL.luan, cuts.luan],
                [SELLER_LABEL.dylan, cuts.dylan],
                ["House", cuts.house],
                ["Profit", cuts.profit],
              ] as const
            ).map(([k, v]) => (
              <div key={k} className="bg-bg px-3 py-5">
                <p className="font-display text-xl tabular-nums">{zar(v)}</p>
                <p className="mt-1 text-[10px] tracking-[0.16em] uppercase text-muted">{k}</p>
              </div>
            ))}
          </div>
        </section>
      ) : null}

      <section className="mt-8">
        <div className="mb-3 flex items-end justify-between gap-3">
          <h2 className="font-display text-2xl">Fourteen days</h2>
          <p className="text-xs text-subtle">Invoiced vs paid</p>
        </div>
        <SalesChart invoices={invoices} />
      </section>

      {invoices.length > 0 ? (
        <section className="mt-10">
          <h2 className="font-display text-2xl">Invoices</h2>
          <ul className="mt-4 divide-y divide-border rounded-[var(--radius-lg)] border border-border">
            {invoices.slice(0, 12).map((inv) => (
              <li key={inv.id}>
                <Link
                  to="/invoices/$id"
                  params={{ id: inv.id }}
                  className="flex min-h-14 items-center justify-between gap-3 px-4 py-3 hover:bg-elevated"
                >
                  <div className="min-w-0">
                    <p className="truncate text-sm">
                      {inv.number} · {inv.name}
                    </p>
                    <p className="text-xs text-muted">
                      {inv.sku} · {inv.look} · {inv.status}
                      {inv.owner ? ` · ${SELLER_LABEL[inv.owner]}` : ""}
                    </p>
                  </div>
                  <p className="shrink-0 text-sm tabular-nums">
                    {zar(invoiceTotal(inv.unitPrice, inv.qty, inv.deliveryFee))}
                  </p>
                </Link>
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      {leads.length === 0 && waiting.length === 0 ? (
        <div className="mt-10 rounded-[var(--radius-lg)] border border-border bg-elevated px-6 py-16 text-center">
          <p className="font-display text-3xl">No one on the board yet</p>
          <p className="mx-auto mt-3 max-w-md text-sm text-muted">
            Website orders appear here. You can also capture a name, phone, and 45xxx.
          </p>
          <Button asChild className="mt-8">
            <Link to="/capture">Capture the first lead</Link>
          </Button>
        </div>
      ) : (
        <div>
          <p className="mt-8 text-xs tracking-[0.16em] uppercase text-subtle md:hidden">
            Swipe the stages
          </p>
          <div className="-mx-4 mt-3 flex min-w-0 snap-x snap-mandatory gap-3 overflow-x-auto px-4 pb-6 [scrollbar-width:thin] md:mx-0 md:mt-8 md:px-0">
            {STAGES.map((stage) => {
              const col = leads.filter((l) => l.status === stage);
              return (
                <section
                  key={stage}
                  className="w-[min(280px,82vw)] shrink-0 snap-start rounded-[var(--radius-lg)] border border-border bg-elevated p-3"
                >
                  <div className="flex items-baseline justify-between px-1 pb-3">
                    <h2 className="text-xs tracking-[0.16em] uppercase text-muted">
                      {STAGE_LABEL[stage]}
                    </h2>
                    <span className="text-xs tabular-nums text-subtle">{col.length}</span>
                  </div>
                  <ul className="space-y-2">
                    {col.map((lead) => {
                      const shoe = liveBySku(products, lead.sku);
                      return (
                        <li key={lead.id}>
                          <Link
                            to="/leads/$id"
                            params={{ id: lead.id }}
                            className="block rounded-[var(--radius-md)] border border-border bg-bg p-3 hover:border-primary"
                          >
                            <p className="truncate text-sm font-medium">{lead.name || "No name"}</p>
                            <p className="mt-1 text-xs tabular-nums text-muted">
                              {lead.sku} · {lead.look}
                              {lead.owner ? ` · ${SELLER_LABEL[lead.owner]}` : ""}
                            </p>
                            <p className="mt-1 text-xs tabular-nums text-subtle">
                              {zar(shoe?.price ?? null)}
                              {lead.size ? ` · UK ${lead.size}` : ""}
                              {lead.source === "website" ? " · site" : ""}
                              {showCost && shoe
                                ? ` · cost ${zar(shoe.cost)}`
                                : ""}
                            </p>
                          </Link>
                          <div className="mt-1 flex gap-1">
                            {nextStages(stage).map((n) => (
                              <button
                                key={n}
                                type="button"
                                onClick={() => moveLead(lead.id, n)}
                                className={cn(
                                  "h-11 flex-1 rounded-[var(--radius-xs)] border border-border text-xs tracking-[0.08em] uppercase text-muted hover:text-fg",
                                )}
                              >
                                {STAGE_LABEL[n]}
                              </button>
                            ))}
                          </div>
                        </li>
                      );
                    })}
                  </ul>
                </section>
              );
            })}
          </div>
        </div>
      )}
    </main>
  );
}

function nextStages(stage: Stage): Stage[] {
  if (stage === "new") return ["contacted", "lost"];
  if (stage === "contacted") return ["qualified", "lost"];
  if (stage === "qualified") return ["negotiation", "lost"];
  if (stage === "negotiation") return ["closed", "lost"];
  if (stage === "closed") return [];
  return ["new"];
}
