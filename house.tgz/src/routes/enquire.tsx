import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { DeliveryPick } from "@/components/delivery-pick";
import { Input, Label } from "@/components/ui/input";
import { ShareBar } from "@/components/share-bar";
import { SizePick } from "@/components/size-pick";
import { useSable } from "@/lib/store";
import { StaffOnly } from "@/components/staff-gate";
import { liveBySku, useLiveProducts } from "@/lib/live";
import { DELIVERY_LABEL, deliveryFee, type DeliveryKind } from "@/lib/money";
import { zar } from "@/lib/utils";

type Search = { sku?: string; size?: string };

export const Route = createFileRoute("/enquire")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    sku: typeof s.sku === "string" ? s.sku : undefined,
    size: typeof s.size === "string" ? s.size : undefined,
  }),
  component: EnquireRoute,
});

function EnquireRoute() {
  return (
    <StaffOnly>
      <Enquire />
    </StaffOnly>
  );
}

function Enquire() {
  const { sku: seed, size: sizeSeed } = Route.useSearch();
  const products = useLiveProducts();
  const rates = useSable((s) => s.delivery);
  const [sku, setSku] = useState(seed ?? products[0]?.sku ?? "");
  const [size, setSize] = useState(sizeSeed ?? "");
  useEffect(() => {
    if (seed) setSku(seed);
  }, [seed]);
  useEffect(() => {
    if (sizeSeed) setSize(sizeSeed);
  }, [sizeSeed]);
  const [qty, setQty] = useState(1);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [note, setNote] = useState("");
  const [delivery, setDelivery] = useState<DeliveryKind>("collect");
  const [customFee, setCustomFee] = useState(0);
  const [copied, setCopied] = useState(false);
  const product = liveBySku(products, sku) ?? products[0];
  const add = useSable((s) => s.addEnquiry);
  if (!product) return null;
  const fee = deliveryFee(delivery, rates, customFee);

  const message = useMemo(() => {
    return [
      "SABLE.CO — 2026 lookbook",
      `Stock: ${product.sku}`,
      `Type: ${product.look}`,
      `Listed: ${zar(product.price)}`,
      size ? `Size: UK ${size}` : "Size: (to confirm)",
      `Qty: ${qty}`,
      `Delivery: ${DELIVERY_LABEL[delivery]}${fee ? ` · ${zar(fee)}` : ""}`,
      name ? `Name: ${name}` : null,
      phone ? `Phone: ${phone}` : null,
      note ? `Note: ${note}` : null,
      "Handmade. Subject to availability.",
      "Reply with UK size + pair count and I will confirm.",
    ]
      .filter(Boolean)
      .join("\n");
  }, [product, size, qty, name, phone, note, delivery, fee]);

  function save() {
    add({
      sku: product.sku,
      look: product.look,
      size,
      qty,
      name,
      phone,
      note,
      delivery,
      deliveryFee: fee,
    });
  }

  async function copy() {
    save();
    await navigator.clipboard.writeText(message);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  }

  const wa = `https://wa.me/?text=${encodeURIComponent(message)}`;

  return (
    <main className="mx-auto grid max-w-6xl gap-10 px-4 py-8 sm:grid-cols-2 sm:px-6 sm:py-10">
      <div className="min-w-0">
        <p className="text-xs tracking-[0.24em] uppercase text-muted">WhatsApp first</p>
        <h1 className="font-display mt-2 text-4xl">Enquire</h1>
        <p className="mt-3 text-sm text-muted">
          Builds the outbound with the 45xxx. Pick a UK size if you know it.
        </p>
        <form
          className="mt-8 space-y-4"
          onSubmit={(e) => {
            e.preventDefault();
            void copy();
          }}
        >
          <div className="space-y-2">
            <Label htmlFor="sku">Stock</Label>
            <select
              id="sku"
              value={sku}
              onChange={(e) => setSku(e.target.value)}
              className="flex h-11 w-full rounded-[var(--radius-sm)] border border-border bg-elevated px-3 text-sm text-fg"
            >
              {products.map((p) => (
                <option key={p.sku} value={p.sku}>
                  {p.sku} · {p.look} · {zar(p.price)}
                </option>
              ))}
            </select>
          </div>
          <SizePick value={size} onChange={setSize} />
          <div className="space-y-2">
            <Label htmlFor="qty">Qty</Label>
            <Input
              id="qty"
              type="number"
              min={1}
              value={qty}
              onChange={(e) => setQty(Number(e.target.value) || 1)}
            />
          </div>
          <DeliveryPick
            kind={delivery}
            custom={customFee}
            rates={rates}
            onKind={setDelivery}
            onCustom={setCustomFee}
          />
          <div className="space-y-2">
            <Label htmlFor="name">Name</Label>
            <Input id="name" value={name} onChange={(e) => setName(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="phone">Phone</Label>
            <Input id="phone" value={phone} onChange={(e) => setPhone(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="note">Note</Label>
            <Input id="note" value={note} onChange={(e) => setNote(e.target.value)} />
          </div>
          <div className="flex flex-col gap-3 pt-2 sm:flex-row">
            <Button type="submit" className="w-full sm:w-auto">
              {copied ? "Copied" : "Copy message"}
            </Button>
            <Button asChild variant="outline" className="w-full sm:w-auto">
              <a href={wa} target="_blank" rel="noreferrer">
                Open WhatsApp
              </a>
            </Button>
          </div>
        </form>
        <div className="mt-10">
          <p className="mb-3 text-xs tracking-[0.16em] uppercase text-muted">Share the house</p>
          <ShareBar compact />
        </div>
      </div>
      <aside className="min-w-0 rounded-[var(--radius-lg)] border border-border bg-elevated p-5 sm:p-6">
        <p className="text-xs tracking-[0.16em] uppercase text-muted">Preview</p>
        <pre className="mt-4 whitespace-pre-wrap font-sans text-sm leading-relaxed text-fg">
          {message}
        </pre>
        <img
          src={product.image}
          alt={`${product.sku} ${product.look}`}
          className="mt-6 aspect-[4/3] w-full rounded-[var(--radius-md)] object-cover"
        />
        <Button asChild variant="ghost" className="mt-4 w-full">
          <Link to="/sizes">Open size guide</Link>
        </Button>
      </aside>
    </main>
  );
}
