import { createFileRoute } from "@tanstack/react-router";
import { useSable } from "@/lib/store";
import { zar } from "@/lib/utils";
import { atLeast } from "@/lib/access";
import { DeskGate, GatePending } from "@/components/desk-gate";
import { useLiveNotes, useLiveProducts } from "@/lib/live";

export const Route = createFileRoute("/memory")({ component: MemoryPage });

function MemoryPage() {
  const hydrated = useSable((s) => s.hydrated);
  const role = useSable((s) => s.deskRole);
  const saved = useSable((s) => s.saved);
  const enquiries = useSable((s) => s.enquiries);
  const leads = useSable((s) => s.leads);
  const products = useLiveProducts();
  const notes = useLiveNotes();
  const looks = products.filter((p) => saved.includes(p.sku));

  if (!hydrated) return <GatePending />;
  if (!atLeast(role, "manager")) return <DeskGate need="manager" />;

  return (
    <main className="mx-auto max-w-6xl px-4 py-8 sm:px-6 sm:py-10">
      <p className="text-xs tracking-[0.24em] uppercase text-muted">Operating brain</p>
      <h1 className="font-display mt-2 text-4xl sm:text-5xl">Sable memory</h1>
      <p className="mt-3 max-w-xl text-sm text-muted">
        Files for this desk. Sales never sees this room. Admin sees the roadmap.
      </p>

      <div className="mt-10 grid gap-4 sm:grid-cols-2">
        {notes.map((note) => (
          <article
            key={note.slug}
            className="rounded-[var(--radius-lg)] border border-border bg-elevated p-5"
          >
            <p className="text-[10px] tracking-[0.18em] uppercase text-primary">{note.tag}</p>
            <h2 className="font-display mt-2 text-2xl">{note.title}</h2>
            <p className="mt-3 whitespace-pre-line text-sm leading-relaxed text-muted">
              {note.body}
            </p>
          </article>
        ))}
      </div>

      <section className="mt-14">
        <h2 className="font-display text-3xl">Device ledger</h2>
        <p className="mt-2 text-sm text-muted">Saved pairs, enquiries, and floor leads stay on this device.</p>
        <div className="mt-6 grid gap-6 lg:grid-cols-3">
          <div className="rounded-[var(--radius-lg)] border border-border p-5">
            <p className="text-xs tracking-[0.16em] uppercase text-muted">Saved</p>
            {looks.length === 0 ? (
              <p className="mt-4 text-sm text-subtle">No pairs saved yet.</p>
            ) : (
              <ul className="mt-4 space-y-2 text-sm">
                {looks.map((p) => (
                  <li key={p.sku} className="flex justify-between gap-3">
                    <span>
                      {p.sku} <span className="text-subtle">{p.look}</span>
                    </span>
                    <span className="tabular-nums">{zar(p.price)}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>
          <div className="rounded-[var(--radius-lg)] border border-border p-5">
            <p className="text-xs tracking-[0.16em] uppercase text-muted">Enquiries</p>
            {enquiries.length === 0 ? (
              <p className="mt-4 text-sm text-subtle">None yet.</p>
            ) : (
              <ul className="mt-4 space-y-3 text-sm">
                {enquiries.map((e) => (
                  <li key={e.id}>
                    <p className="text-fg">
                      {e.sku} · {e.look}
                    </p>
                    <p className="text-muted">
                      Size {e.size || "—"} · Qty {e.qty} · {e.name || "anon"}
                    </p>
                  </li>
                ))}
              </ul>
            )}
          </div>
          <div className="rounded-[var(--radius-lg)] border border-border p-5">
            <p className="text-xs tracking-[0.16em] uppercase text-muted">Floor</p>
            {leads.length === 0 ? (
              <p className="mt-4 text-sm text-subtle">No leads on this device.</p>
            ) : (
              <ul className="mt-4 space-y-3 text-sm">
                {leads.slice(0, 12).map((l) => (
                  <li key={l.id}>
                    <p className="text-fg">
                      {l.name} · {l.sku}
                    </p>
                    <p className="text-muted">
                      {l.status} · {l.look}
                    </p>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </section>
    </main>
  );
}
