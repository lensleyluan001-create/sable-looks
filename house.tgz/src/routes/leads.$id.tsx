import { createFileRoute, Link, notFound, useNavigate } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { ChipRow, chipClass } from "@/components/chip-row";
import { CommissionCard } from "@/components/commission-card";
import { Input, Label } from "@/components/ui/input";
import { SellerPick } from "@/components/seller-pick";
import { StaffOnly } from "@/components/staff-gate";
import { atLeast } from "@/lib/access";
import { firstContact, SOURCE_LABEL, STAGE_LABEL, STAGES, waHref } from "@/lib/floor";
import { liveBySku, useLiveProducts } from "@/lib/live";
import { DELIVERY_LABEL, deliveryFee, type DeliveryKind } from "@/lib/money";
import { assignHouseOrder } from "@/lib/house-orders";
import { pairProfit, type SellerId } from "@/lib/people";
import { useSable } from "@/lib/store";
import { zar } from "@/lib/utils";

export const Route = createFileRoute("/leads/$id")({ component: LeadRoute });

function LeadRoute() {
  return (
    <StaffOnly>
      <LeadPage />
    </StaffOnly>
  );
}

function LeadPage() {
  const { id } = Route.useParams();
  const lead = useSable((s) => s.leads.find((l) => l.id === id));
  const allInvoices = useSable((s) => s.invoices);
  const invoices = allInvoices.filter((n) => n.leadId === id);
  const updateLead = useSable((s) => s.updateLead);
  const moveLead = useSable((s) => s.moveLead);
  const addInvoice = useSable((s) => s.addInvoice);
  const token = useSable((s) => s.deskToken);
  const rates = useSable((s) => s.delivery);
  const role = useSable((s) => s.deskRole);
  const products = useLiveProducts();
  const navigate = useNavigate();
  if (!lead) throw notFound();
  const shoe = liveBySku(products, lead.sku);
  const showCost = atLeast(role, "manager") && shoe;
  const canAssign = atLeast(role, "manager");
  const message = firstContact(
    lead.name,
    lead.sku,
    lead.look,
    zar(shoe?.price ?? null),
  );

  function raise() {
    if (!lead || !shoe) return;
    const inv = addInvoice({
      leadId: lead.id,
      name: lead.name,
      phone: lead.phone,
      address: lead.address,
      sku: lead.sku,
      look: lead.look,
      size: lead.size,
      qty: lead.qty,
      unitPrice: shoe.price,
      delivery: lead.delivery,
      deliveryFee: lead.deliveryFee,
      note: lead.note,
      owner: lead.owner,
    });
    if (lead.status !== "closed") moveLead(lead.id, "closed");
    void navigate({ to: "/invoices/$id", params: { id: inv.id } });
  }

  function setDelivery(kind: DeliveryKind) {
    if (!lead) return;
    updateLead(lead.id, {
      delivery: kind,
      deliveryFee: deliveryFee(kind, rates, lead.deliveryFee),
    });
  }

  async function setOwner(seller: SellerId | null) {
    if (!lead) return;
    updateLead(lead.id, {
      owner: seller,
      assignedBy: seller ? "manager" : null,
    });
    if (lead.orderId && seller && token) {
      await assignHouseOrder({ data: { token, id: lead.orderId, seller } });
    }
  }

  return (
    <main className="mx-auto grid max-w-6xl gap-10 px-4 py-8 sm:grid-cols-2 sm:px-6 sm:py-10">
      <div className="min-w-0">
        <p className="text-xs tracking-[0.24em] uppercase text-muted">
          {SOURCE_LABEL[lead.source]} · {STAGE_LABEL[lead.status]}
        </p>
        <h1 className="font-display mt-2 text-4xl">{lead.name}</h1>
        <p className="mt-2 text-sm text-muted">{lead.phone || "No phone yet"}</p>

        <ChipRow className="mt-8" edge>
          {STAGES.map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => moveLead(lead.id, s)}
              className={chipClass(lead.status === s)}
            >
              {STAGE_LABEL[s]}
            </button>
          ))}
        </ChipRow>

        <div className="mt-8 space-y-4">
          {canAssign ? (
            <div className="space-y-2">
              <Label>Seller</Label>
              <SellerPick value={lead.owner} onChange={(s) => void setOwner(s)} />
            </div>
          ) : lead.owner ? (
            <p className="text-sm text-muted">Assigned to this desk</p>
          ) : (
            <p className="text-sm text-muted">Waiting on a manager to assign</p>
          )}
          <div className="space-y-2">
            <Label>Delivery</Label>
            <div className="grid grid-cols-2 gap-2">
              {(["collect", "local", "international", "custom"] as const).map((k) => (
                <button
                  key={k}
                  type="button"
                  onClick={() => setDelivery(k)}
                  className={chipClass(lead.delivery === k)}
                >
                  {DELIVERY_LABEL[k]}
                </button>
              ))}
            </div>
            {lead.delivery === "custom" ? (
              <Input
                type="number"
                min={0}
                value={lead.deliveryFee}
                onChange={(e) =>
                  updateLead(lead.id, { deliveryFee: Number(e.target.value) || 0 })
                }
              />
            ) : (
              <p className="text-xs text-subtle">{zar(lead.deliveryFee)} on this pair</p>
            )}
          </div>
          <div className="space-y-2">
            <Label htmlFor="address">Address</Label>
            <Input
              id="address"
              value={lead.address}
              onChange={(e) => updateLead(lead.id, { address: e.target.value })}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="note">Note</Label>
            <Input
              id="note"
              value={lead.note}
              onChange={(e) => updateLead(lead.id, { note: e.target.value })}
            />
          </div>
          <div className="flex flex-col gap-3 sm:flex-row sm:flex-wrap">
            <Button asChild className="w-full sm:w-auto">
              <a href={waHref(lead.phone, message)} target="_blank" rel="noreferrer">
                WhatsApp
              </a>
            </Button>
            <Button type="button" variant="outline" className="w-full sm:w-auto" onClick={raise} disabled={!shoe}>
              Raise invoice
            </Button>
            <Button asChild variant="ghost" className="w-full sm:w-auto">
              <Link to="/floor">Back to floor</Link>
            </Button>
          </div>
        </div>

        {invoices.length > 0 ? (
          <div className="mt-10">
            <p className="text-xs tracking-[0.16em] uppercase text-muted">Invoices</p>
            <ul className="mt-3 space-y-2">
              {invoices.map((inv) => (
                <li key={inv.id}>
                  <Link
                    to="/invoices/$id"
                    params={{ id: inv.id }}
                    className="text-sm text-primary hover:underline"
                  >
                    {inv.number} · {inv.status}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ) : null}
      </div>

      <aside className="min-w-0 space-y-4">
        <div className="rounded-[var(--radius-lg)] border border-border bg-elevated p-6">
          {shoe ? (
            <>
              <img
                src={shoe.image}
                alt={shoe.sku}
                className="aspect-[4/3] w-full rounded-[var(--radius-md)] object-cover"
              />
              <p className="mt-4 font-display text-3xl tabular-nums">{shoe.sku}</p>
              <p className="mt-1 text-sm text-muted">
                {shoe.look} · {zar(shoe.price)}
                {lead.size ? ` · UK ${lead.size}` : ""}
                {` · qty ${lead.qty}`}
              </p>
              {showCost ? (
                <p className="mt-2 text-xs text-subtle">
                  Factory cost {zar(shoe.cost)} · about {zar(shoe.price - shoe.cost)} on the
                  pair. Sales never see this.
                </p>
              ) : null}
              <Button asChild variant="outline" className="mt-6">
                <Link to="/product/$sku" params={{ sku: shoe.sku }}>
                  Open lookbook
                </Link>
              </Button>
            </>
          ) : (
            <p className="text-sm text-muted">Stock {lead.sku} is not in the 2026 book.</p>
          )}
          <pre className="mt-6 whitespace-pre-wrap font-sans text-sm leading-relaxed text-fg">
            {message}
          </pre>
        </div>
        {showCost && lead.owner && shoe ? (
          <CommissionCard
            seller={lead.owner}
            profit={pairProfit(shoe.price, shoe.cost, lead.qty)}
          />
        ) : null}
      </aside>
    </main>
  );
}
