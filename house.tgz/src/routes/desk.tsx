import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState, type FormEvent } from "react";
import { openDesk } from "@/lib/desk";
import { runHouse, type ChatTurn, type HouseDid } from "@/lib/house-agent";
import { ROLE_LABEL, atLeast, type Role } from "@/lib/access";
import { useSable } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Input, Label } from "@/components/ui/input";
import { useLiveNotes, useLiveProducts } from "@/lib/live";

export const Route = createFileRoute("/desk")({ component: DeskPage });

const DID_LABEL: Record<HouseDid, string> = {
  price: "Listed price live",
  look: "Look name live",
  note: "Memory filed",
  copy: "Page copy live",
  featured: "Selected looks live",
  reset: "House reset",
  enquiry: "Draft stored",
};

function chipsFor(role: Role) {
  const base = ["45004", "golfers", "WhatsApp for 45008", "vellies"];
  if (role === "sales") return base;
  if (role === "manager") return [...base, "factory", "enquiries"];
  return [
    ...base,
    "set 45004 to 1250",
    "feature items 1, 4, 15, 88",
    "note: Bench window — Confirm 45004 before Friday.",
  ];
}

function DeskPage() {
  const role = useSable((s) => s.deskRole);
  const setDesk = useSable((s) => s.setDesk);
  const clearDesk = useSable((s) => s.clearDesk);
  const setPrice = useSable((s) => s.setPrice);
  const clearPrice = useSable((s) => s.clearPrice);
  const setLook = useSable((s) => s.setLook);
  const setNoteBody = useSable((s) => s.setNoteBody);
  const addNote = useSable((s) => s.addNote);
  const addEnquiry = useSable((s) => s.addEnquiry);
  const setCopy = useSable((s) => s.setCopy);
  const setFeatured = useSable((s) => s.setFeatured);
  const resetOverrides = useSable((s) => s.resetOverrides);
  const copy = useSable((s) => s.copy);
  const featured = useSable((s) => s.featured);
  const enquiries = useSable((s) => s.enquiries);
  const products = useLiveProducts();
  const notes = useLiveNotes();
  const [code, setCode] = useState("");
  const [gateError, setGateError] = useState("");
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<(ChatTurn & { did?: HouseDid })[]>([]);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  async function elevate(e: FormEvent) {
    e.preventDefault();
    setGateError("");
    const res = await openDesk({ data: { code } });
    if (!res.ok) {
      setGateError(res.error);
      return;
    }
    setDesk(res.role, res.token);
    setCode("");
    setMessages([]);
  }

  function ask(text: string) {
    const q = text.trim();
    if (!q) return;
    const reply = runHouse(q, {
      role,
      products,
      notes,
      enquiries,
      history: messages,
      copy,
      featured,
      setPrice,
      clearPrice,
      setLook,
      setNoteBody,
      addNote,
      addEnquiry: (e) =>
        addEnquiry({
          ...e,
          delivery: "collect",
          deliveryFee: 0,
        }),
      setCopy,
      setFeatured,
      resetOverrides,
    });
    setMessages((m) => [
      ...m,
      { role: "user", content: q },
      { role: "assistant", content: reply.text, did: reply.did },
    ]);
    setInput("");
  }

  function send(e: FormEvent) {
    e.preventDefault();
    ask(input);
  }

  return (
    <main className="mx-auto grid max-w-6xl gap-8 px-4 py-8 lg:grid-cols-[minmax(0,1fr)_280px] sm:px-6 sm:py-10">
      <aside className="min-w-0 space-y-6 lg:col-start-2 lg:row-start-1">
        <div className="rounded-[var(--radius-lg)] border border-border p-5">
          <p className="text-xs tracking-[0.16em] uppercase text-muted">This desk</p>
          <p className="font-display mt-2 text-2xl">{ROLE_LABEL[role]}</p>
          {atLeast(role, "manager") ? (
            <Button type="button" variant="outline" className="mt-4 w-full" onClick={clearDesk}>
              Back to sales
            </Button>
          ) : (
            <form onSubmit={elevate} className="mt-4 space-y-3">
              <Label htmlFor="code">Manager / admin code</Label>
              <Input
                id="code"
                type="password"
                autoComplete="off"
                value={code}
                onChange={(e) => setCode(e.target.value)}
              />
              {gateError ? <p className="text-sm text-leather">{gateError}</p> : null}
              <Button type="submit" variant="outline" className="w-full">
                Elevate
              </Button>
            </form>
          )}
          {atLeast(role, "manager") ? (
            <Button asChild variant="outline" className="mt-3 w-full">
              <Link to="/build">Open Build</Link>
            </Button>
          ) : null}
        </div>
        <div className="rounded-[var(--radius-lg)] border border-border p-5">
          <p className="text-xs tracking-[0.16em] uppercase text-muted">Files in play</p>
          <ul className="mt-3 space-y-1 text-sm text-muted">
            {notes.map((n) => (
              <li key={n.slug}>{n.title}</li>
            ))}
            <li>2026 catalogue · {products.length} SKUs</li>
          </ul>
        </div>
      </aside>

      <section className="min-w-0 lg:col-start-1 lg:row-start-1">
        <p className="text-xs tracking-[0.16em] uppercase text-muted">House assistant</p>
        <h1 className="font-display mt-2 text-4xl">Desk</h1>
        <p className="mt-3 max-w-xl text-sm text-muted">
          Runs on house files only. Does not spend Grok usage. {ROLE_LABEL[role]} —{" "}
          {atLeast(role, "admin")
            ? "can change prices, names, files, and the house page."
            : atLeast(role, "manager")
              ? "full memory, no catalogue edits."
              : "listed prices and scripts only."}
        </p>

        <div className="mt-8 min-h-[280px] rounded-[var(--radius-lg)] border border-border bg-elevated p-4">
          {messages.length === 0 ? (
            <div>
              <p className="text-sm text-subtle">Ask the house. It quotes, drafts, and — on admin — writes live.</p>
              <div className="mt-4 flex flex-wrap gap-2">
                {chipsFor(role).map((c) => (
                  <button
                    key={c}
                    type="button"
                    className="min-h-11 rounded-full border border-border px-3 py-2 text-left text-xs text-muted hover:text-fg"
                    onClick={() => ask(c)}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <ul className="space-y-4">
              {messages.map((m, i) => (
                <li key={`${m.role}-${i}`}>
                  <p className="text-[10px] tracking-[0.16em] uppercase text-muted">
                    {m.role === "user" ? "You" : "Sable"}
                    {m.did ? ` · ${DID_LABEL[m.did]}` : ""}
                  </p>
                  <p className="mt-1 whitespace-pre-wrap text-sm leading-relaxed">{m.content}</p>
                </li>
              ))}
            </ul>
          )}
          <div ref={endRef} />
        </div>

        <form onSubmit={send} className="mt-4 flex flex-col gap-2 sm:flex-row">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask the house"
          />
          <Button type="submit" className="w-full sm:w-auto">Ask</Button>
        </form>
      </section>
    </main>
  );
}
