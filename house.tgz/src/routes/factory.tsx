import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { DeskGate, GatePending } from "@/components/desk-gate";
import { atLeast } from "@/lib/access";
import { housePhoto } from "@/lib/catalogue";
import { useSable } from "@/lib/store";

export const Route = createFileRoute("/factory")({ component: Factory });

function Factory() {
  const hydrated = useSable((s) => s.hydrated);
  const role = useSable((s) => s.deskRole);
  const copy = useSable((s) => s.copy);

  if (!hydrated) return <GatePending />;
  if (!atLeast(role, "manager")) return <DeskGate need="manager" />;

  return (
    <main>
      <section className="relative min-h-[48vh] overflow-hidden">
        <img
          src={housePhoto("factory")}
          alt="Sable factory bench with lasts and cut leather"
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-bg via-bg/50 to-transparent" />
        <div className="relative mx-auto flex min-h-[48vh] max-w-6xl items-end px-4 py-14 sm:px-6">
          <h1 className="font-display text-4xl sm:text-6xl">{copy.factoryTitle}</h1>
        </div>
      </section>
      <section className="mx-auto grid max-w-6xl gap-10 px-4 py-16 sm:grid-cols-2 sm:px-6">
        <div>
          <p className="text-xs tracking-[0.22em] uppercase text-muted">Make</p>
          <h2 className="font-display mt-2 text-3xl">{copy.factoryLead}</h2>
          <p className="mt-4 whitespace-pre-line text-sm leading-relaxed text-muted">
            {copy.factoryBody}
          </p>
        </div>
        <div className="rounded-[var(--radius-lg)] border border-border bg-elevated p-6">
          <p className="text-xs tracking-[0.16em] uppercase text-muted">Working rule</p>
          <ul className="mt-4 space-y-3 text-sm text-fg/90">
            <li>Do not quote a pair as in-stock until the bench confirms.</li>
            <li>Catalogue prices are listed ZAR, subject to availability.</li>
            <li>Track every shoe as 45001–45092. The name is the type.</li>
            <li>Sable is the live desk. Move stock. Send the pair.</li>
          </ul>
          <Button asChild className="mt-8" variant="outline">
            <Link to="/memory">Read the memory</Link>
          </Button>
        </div>
      </section>
    </main>
  );
}
