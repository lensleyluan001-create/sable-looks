import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { InvoiceDoc } from "@/components/invoice-doc";
import { atLeast } from "@/lib/access";
import { waHref } from "@/lib/floor";
import { invoiceTotal } from "@/lib/money";
import { useSable } from "@/lib/store";
import { zar } from "@/lib/utils";

export const Route = createFileRoute("/invoices/$id")({ component: InvoicePage });

function InvoicePage() {
  const { id } = Route.useParams();
  const invoice = useSable((s) => s.invoices.find((n) => n.id === id));
  const copy = useSable((s) => s.copy);
  const setStatus = useSable((s) => s.setInvoiceStatus);
  const role = useSable((s) => s.deskRole);
  if (!invoice) throw notFound();
  const total = invoiceTotal(invoice.unitPrice, invoice.qty, invoice.deliveryFee);
  const text = [
    `SABLE.CO ${invoice.number}`,
    `${invoice.name}`,
    `${invoice.sku} · ${invoice.look} · ×${invoice.qty}`,
    `Total ${zar(total)}`,
    copy.invoicePay,
  ].join("\n");

  return (
    <main className="mx-auto max-w-lg px-4 py-8 sm:px-6">
      <p className="text-xs tracking-[0.24em] uppercase text-muted">Invoice</p>
      <h1 className="font-display mt-2 text-4xl">{invoice.number}</h1>
      <p className="mt-2 text-sm text-muted">
        Built to screenshot. Send it on WhatsApp as-is.
      </p>

      <div className="mt-8">
        <InvoiceDoc invoice={invoice} copy={copy} />
      </div>

      <div className="mt-6 flex flex-col gap-3">
        {atLeast(role, "sales") ? (
          <Button
            type="button"
            className="w-full"
            variant={invoice.status === "paid" ? "outline" : "default"}
            onClick={() =>
              setStatus(invoice.id, invoice.status === "paid" ? "open" : "paid")
            }
          >
            {invoice.status === "paid" ? "Mark open" : "Mark paid"}
          </Button>
        ) : null}
        <Button asChild variant="outline" className="w-full">
          <a href={waHref(invoice.phone, text)} target="_blank" rel="noreferrer">
            Send on WhatsApp
          </a>
        </Button>
        <Button
          type="button"
          variant="outline"
          className="w-full"
          onClick={() => window.print()}
        >
          Print
        </Button>
        <Button asChild variant="ghost" className="w-full">
          <Link to="/floor">Back to floor</Link>
        </Button>
      </div>
    </main>
  );
}
