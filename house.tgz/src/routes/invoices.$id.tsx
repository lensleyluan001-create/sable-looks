import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { CommissionCard } from "@/components/commission-card";
import { InvoiceDoc } from "@/components/invoice-doc";
import { StaffOnly } from "@/components/staff-gate";
import { atLeast } from "@/lib/access";
import { waHref } from "@/lib/floor";
import { liveBySku, useLiveProducts } from "@/lib/live";
import { invoiceTotal } from "@/lib/money";
import { pairProfit } from "@/lib/people";
import { useSable } from "@/lib/store";
import { zar } from "@/lib/utils";

export const Route = createFileRoute("/invoices/$id")({ component: InvoiceRoute });

function InvoiceRoute() {
  return (
    <StaffOnly>
      <InvoicePage />
    </StaffOnly>
  );
}

function InvoicePage() {
  const { id } = Route.useParams();
  const invoice = useSable((s) => s.invoices.find((n) => n.id === id));
  const copy = useSable((s) => s.copy);
  const setStatus = useSable((s) => s.setInvoiceStatus);
  const role = useSable((s) => s.deskRole);
  const products = useLiveProducts();
  if (!invoice) throw notFound();
  const total = invoiceTotal(invoice.unitPrice, invoice.qty, invoice.deliveryFee);
  const shoe = liveBySku(products, invoice.sku);
  const showSplit = atLeast(role, "manager") && invoice.owner && shoe;
  const text = [
    `SABLE.CO ${invoice.number}`,
    `${invoice.name}`,
    `${invoice.sku} · ${invoice.look} · ×${invoice.qty}`,
    `Total ${zar(total)}`,
    copy.invoicePay,
  ].join("\n");

  return (
    <main className="mx-auto max-w-lg px-4 py-8 sm:px-6">
      <p className="text-xs tracking-[0.24em] uppercase text-muted">Invoice</p>
      <h1 className="font-display mt-2 text-4xl">{invoice.number}</h1>
      <p className="mt-2 text-sm text-muted">
        Built to screenshot. Send it on WhatsApp as-is.
      </p>

      <div className="mt-8">
        <InvoiceDoc invoice={invoice} copy={copy} />
      </div>

      {showSplit && shoe && invoice.owner ? (
        <div className="mt-6">
          <CommissionCard
            seller={invoice.owner}
            profit={pairProfit(shoe.price, shoe.cost, invoice.qty)}
          />
        </div>
      ) : null}

      <div className="mt-6 flex flex-col gap-3">
        {atLeast(role, "sales") ? (
          <Button
            type="button"
            className="w-full"
            variant={invoice.status === "paid" ? "outline" : "default"}
            onClick={() =>
              setStatus(invoice.id, invoice.status === "paid" ? "open" : "paid")
            }
          >
            {invoice.status === "paid" ? "Mark open" : "Mark paid"}
          </Button>
        ) : null}
        <Button asChild variant="outline" className="w-full">
          <a href={waHref(invoice.phone, text)} target="_blank" rel="noreferrer">
            Send on WhatsApp
          </a>
        </Button>
        <Button
          type="button"
          variant="outline"
          className="w-full"
          onClick={() => window.print()}
        >
          Print
        </Button>
        <Button asChild variant="ghost" className="w-full">
          <Link to="/floor">Back to floor</Link>
        </Button>
      </div>
    </main>
  );
}
