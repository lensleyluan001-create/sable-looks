import { SELLER_LABEL, SELLERS, type SellerId } from "@/lib/people";
import { cn } from "@/lib/utils";

export function SellerPick({
  value,
  onChange,
  allowEmpty = true,
}: {
  value: SellerId | null;
  onChange: (seller: SellerId | null) => void;
  allowEmpty?: boolean;
}) {
  return (
    <div className="flex flex-wrap gap-2">
      {allowEmpty ? (
        <button
          type="button"
          onClick={() => onChange(null)}
          className={cn(
            "h-11 rounded-full border px-4 text-xs tracking-[0.14em] uppercase",
            value == null
              ? "border-primary bg-primary text-primary-foreground"
              : "border-border text-muted hover:text-fg",
          )}
        >
          Unassigned
        </button>
      ) : null}
      {SELLERS.map((id) => (
        <button
          key={id}
          type="button"
          onClick={() => onChange(id)}
          className={cn(
            "h-11 rounded-full border px-4 text-xs tracking-[0.14em] uppercase",
            value === id
              ? "border-primary bg-primary text-primary-foreground"
              : "border-border text-muted hover:text-fg",
          )}
        >
          {SELLER_LABEL[id]}
        </button>
      ))}
    </div>
  );
}
