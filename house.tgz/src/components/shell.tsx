import { useEffect, useState, type ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import {
  BookOpen,
  Columns3,
  Factory,
  Home,
  KeyRound,
  LayoutGrid,
  Menu,
  MessageCircle,
  Ruler,
  SlidersHorizontal,
  UserPlus,
  X,
  type LucideIcon,
} from "lucide-react";
import { cn } from "@/lib/utils";
import {
  ADMIN_NAV,
  FLOOR_NAV,
  PUBLIC_NAV,
  ROLE_LABEL,
  SALES_NAV,
  atLeast,
  drawerItems,
  phoneTabs,
} from "@/lib/access";
import { useSable } from "@/lib/store";

const ICONS: Record<string, LucideIcon> = {
  "/": Home,
  "/collection": LayoutGrid,
  "/sizes": Ruler,
  "/enquire": MessageCircle,
  "/floor": Columns3,
  "/capture": UserPlus,
  "/build": SlidersHorizontal,
  "/desk": KeyRound,
  "/factory": Factory,
  "/memory": BookOpen,
};

function isActivePath(pathname: string, to: string) {
  return to === "/" ? pathname === "/" : pathname.startsWith(to);
}

export function Shell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const hydrated = useSable((s) => s.hydrated);
  const deskRole = useSable((s) => s.deskRole);
  const deskToken = useSable((s) => s.deskToken);
  const copy = useSable((s) => s.copy);
  const role = hydrated ? deskRole : "sales";
  const hasDesk = hydrated && Boolean(deskToken);
  const nav = !hasDesk
    ? PUBLIC_NAV
    : atLeast(role, "admin")
      ? ADMIN_NAV
      : atLeast(role, "manager")
        ? FLOOR_NAV
        : SALES_NAV;
  const tabs = phoneTabs(role, hasDesk);
  const menu = drawerItems(nav, hasDesk);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [open]);

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <header className="sticky top-0 z-40 border-b border-border bg-bg/90 pt-[env(safe-area-inset-top)] backdrop-blur-sm">
        <div className="mx-auto flex h-14 max-w-6xl items-center justify-between gap-3 px-4 sm:px-6">
          <Link to="/" className="font-display shrink-0 text-lg tracking-[0.18em] text-fg sm:text-xl">
            SABLE.CO
          </Link>
          <nav className="hidden min-w-0 flex-1 items-center justify-end gap-1 overflow-x-auto [scrollbar-width:none] md:flex [&::-webkit-scrollbar]:hidden">
            {nav.map((item) => {
              const active = isActivePath(pathname, item.to);
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={cn(
                    "shrink-0 rounded-[var(--radius-sm)] px-3 py-2 text-xs tracking-[0.14em] uppercase transition-colors duration-[var(--motion-quick)]",
                    active ? "bg-elevated text-fg" : "text-muted hover:text-fg",
                  )}
                >
                  {item.label}
                </Link>
              );
            })}
            <Link
              to="/desk"
              className="shrink-0 rounded-full border border-border px-3 py-2 text-xs tracking-[0.16em] uppercase text-muted hover:text-fg"
            >
              {hasDesk ? ROLE_LABEL[role] : "Desk"}
            </Link>
          </nav>
          <div className="flex items-center gap-1 md:hidden">
            <Link
              to="/desk"
              className="inline-flex h-11 items-center rounded-full border border-border px-3 text-xs tracking-[0.16em] uppercase text-muted"
            >
              {hasDesk ? ROLE_LABEL[role] : "Desk"}
            </Link>
            <button
              type="button"
              className="grid size-11 place-items-center text-fg"
              aria-label="Open menu"
              aria-expanded={open}
              onClick={() => setOpen(true)}
            >
              <Menu size={20} strokeWidth={1.75} />
            </button>
          </div>
        </div>
      </header>

      {open ? (
        <div className="fixed inset-0 z-50 md:hidden" data-mobile-drawer>
          <button
            type="button"
            className="absolute inset-0 bg-bg/70"
            aria-label="Dismiss menu"
            onClick={() => setOpen(false)}
          />
          <nav
            className="absolute inset-y-0 right-0 z-10 flex w-[min(20rem,86vw)] flex-col border-l border-border bg-elevated pt-[env(safe-area-inset-top)]"
            role="dialog"
            aria-modal="true"
            aria-label="Menu"
          >
            <div className="flex h-14 items-center justify-between px-4">
              <p className="font-display text-lg tracking-[0.18em]">SABLE.CO</p>
              <button
                type="button"
                className="grid size-11 place-items-center"
                aria-label="Close menu"
                onClick={() => setOpen(false)}
              >
                <X size={20} strokeWidth={1.75} />
              </button>
            </div>
            <ul className="flex-1 space-y-1 overflow-y-auto px-3 pb-[calc(5rem+env(safe-area-inset-bottom))]">
              {menu.map((item) => {
                const Icon = ICONS[item.to] ?? LayoutGrid;
                const active = isActivePath(pathname, item.to);
                return (
                  <li key={item.to}>
                    <Link
                      to={item.to}
                      className={cn(
                        "flex min-h-12 items-center gap-3 rounded-[var(--radius-md)] px-3 text-sm tracking-[0.12em] uppercase",
                        active ? "bg-bg text-fg" : "text-muted hover:text-fg",
                      )}
                    >
                      <Icon size={18} strokeWidth={1.6} />
                      {item.label}
                    </Link>
                  </li>
                );
              })}
            </ul>
          </nav>
        </div>
      ) : null}

      {children}

      <footer className="border-t border-border pb-[calc(4.25rem+env(safe-area-inset-bottom))] md:pb-0">
        <div className="mx-auto flex max-w-6xl flex-col gap-3 px-4 py-8 text-xs text-muted sm:flex-row sm:items-end sm:justify-between sm:px-6">
          <div>
            <p className="font-display text-lg tracking-[0.18em] text-fg">SABLE.CO</p>
            <p className="mt-1">Our shoes · 2026</p>
          </div>
          <div className="max-w-sm sm:text-right">
            <p>{copy.deliveryNote}</p>
            <p className="mt-3 flex flex-wrap gap-x-4 gap-y-2 sm:justify-end">
              <Link to="/collection" className="hover:text-fg">
                Collection
              </Link>
              <Link to="/sizes" className="hover:text-fg">
                Size guide
              </Link>
              <Link to="/enquire" className="hover:text-fg">
                Enquire
              </Link>
            </p>
            <p className="mt-2">Prices as listed · Subject to availability</p>
          </div>
        </div>
      </footer>

      <nav
        data-mobile-nav
        className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-bg/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-sm md:hidden"
        aria-label="Primary"
      >
        <ul className={cn("mx-auto grid h-14 max-w-lg", tabs.length === 4 ? "grid-cols-4" : "grid-cols-3")}>
          {tabs.map((item) => {
            const Icon = ICONS[item.to] ?? LayoutGrid;
            const active = isActivePath(pathname, item.to);
            return (
              <li key={item.to} className="min-w-0">
                <Link
                  to={item.to}
                  className={cn(
                    "flex h-14 min-h-11 flex-col items-center justify-center gap-1 px-1 text-[10px] tracking-[0.1em] uppercase",
                    active ? "text-fg" : "text-muted",
                  )}
                >
                  <Icon size={18} strokeWidth={active ? 2 : 1.6} />
                  <span className="max-w-full truncate">{item.label}</span>
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
    </div>
  );
}
