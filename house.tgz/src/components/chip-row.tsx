import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function ChipRow({
  children,
  className,
  edge = false,
}: {
  children: ReactNode;
  className?: string;
  edge?: boolean;
}) {
  return (
    <div
      className={cn(
        "flex min-w-0 gap-2 overflow-x-auto [scrollbar-width:none] [&::-webkit-scrollbar]:hidden sm:flex-wrap sm:overflow-visible",
        edge && "-mx-4 px-4 sm:mx-0 sm:px-0",
        className,
      )}
    >
      {children}
    </div>
  );
}

export function chipClass(active: boolean) {
  return cn(
    "h-11 shrink-0 rounded-full border px-4 text-xs tracking-[0.14em] uppercase",
    active
      ? "border-primary bg-primary text-primary-foreground"
      : "border-border text-muted hover:text-fg",
  );
}
