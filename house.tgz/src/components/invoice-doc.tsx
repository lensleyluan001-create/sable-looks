import { DELIVERY_LABEL } from "@/lib/money";
import { invoiceTotal, lineTotal } from "@/lib/money";
import type { Invoice } from "@/lib/floor";
import type { HouseCopy } from "@/lib/copy";
import { zar } from "@/lib/utils";

export function InvoiceDoc({
  invoice,
  copy,
}: {
  invoice: Invoice;
  copy: HouseCopy;
}) {
  const goods = lineTotal(invoice.unitPrice, invoice.qty);
  const total = invoiceTotal(invoice.unitPrice, invoice.qty, invoice.deliveryFee);
  const day = new Date(invoice.at).toLocaleDateString("en-ZA", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });

  return (
    <article className="mx-auto w-full max-w-md rounded-[var(--radius-lg)] bg-paper px-5 py-6 text-ink shadow-sm sm:px-7 sm:py-8">
      <header className="flex items-start justify-between gap-4 border-b border-ink/10 pb-5">
        <div>
          <p className="font-display text-3xl tracking-[0.14em]">SABLE.CO</p>
          <p className="mt-2 whitespace-pre-line text-xs leading-relaxed text-ink/70">
            {copy.invoiceFrom}
          </p>
        </div>
        <div className="text-right">
          <p className="text-xs tracking-[0.18em] uppercase text-ink/50">Invoice</p>
          <p className="mt-1 font-display text-xl tabular-nums">{invoice.number}</p>
          <p className="mt-1 text-xs text-ink/60">{day}</p>
          <p className="mt-2 text-xs tracking-[0.14em] uppercase text-ink/50">
            {invoice.status === "paid" ? "Paid" : "Open"}
          </p>
        </div>
      </header>

      <section className="mt-5">
        <p className="text-xs tracking-[0.16em] uppercase text-ink/50">Bill to</p>
        <p className="mt-1 text-sm font-medium">{invoice.name}</p>
        {invoice.phone ? <p className="text-xs text-ink/70">{invoice.phone}</p> : null}
        {invoice.address ? (
          <p className="mt-1 whitespace-pre-line text-xs text-ink/70">{invoice.address}</p>
        ) : null}
      </section>

      <table className="mt-6 w-full text-left text-sm">
        <thead>
          <tr className="border-b border-ink/10 text-xs tracking-[0.14em] uppercase text-ink/50">
            <th className="pb-2 font-medium">Pair</th>
            <th className="pb-2 text-right font-medium">Amt</th>
          </tr>
        </thead>
        <tbody>
          <tr className="align-top">
            <td className="py-3">
              <p className="tabular-nums">{invoice.sku}</p>
              <p className="text-xs text-ink/70">
                {invoice.look}
                {invoice.size ? ` · UK ${invoice.size}` : ""}
                {` · ×${invoice.qty}`}
              </p>
              <p className="text-xs text-ink/50">{zar(invoice.unitPrice)} each</p>
            </td>
            <td className="py-3 text-right tabular-nums">{zar(goods)}</td>
          </tr>
          <tr className="border-t border-ink/10">
            <td className="py-3 text-xs text-ink/70">{DELIVERY_LABEL[invoice.delivery]}</td>
            <td className="py-3 text-right tabular-nums">
              {invoice.deliveryFee ? zar(invoice.deliveryFee) : "—"}
            </td>
          </tr>
        </tbody>
      </table>

      <div className="mt-2 flex items-baseline justify-between border-t border-ink/20 pt-4">
        <p className="text-xs tracking-[0.16em] uppercase text-ink/50">Total</p>
        <p className="font-display text-3xl tabular-nums">{zar(total)}</p>
      </div>

      {invoice.note ? (
        <p className="mt-5 text-xs leading-relaxed text-ink/70">{invoice.note}</p>
      ) : null}

      <footer className="mt-6 border-t border-ink/10 pt-4 text-xs leading-relaxed text-ink/60">
        <p className="whitespace-pre-line">{copy.invoicePay}</p>
        <p className="mt-2">{copy.invoiceNote}</p>
      </footer>
    </article>
  );
}
