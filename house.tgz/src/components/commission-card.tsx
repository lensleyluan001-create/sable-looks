import { SELLER_LABEL, splitProfit, type SellerId } from "@/lib/people";
import { zar } from "@/lib/utils";

export function CommissionCard({
  profit,
  seller,
}: {
  profit: number;
  seller: SellerId;
}) {
  const split = splitProfit(profit, seller);
  const rows: Array<[string, number]> = [
    [SELLER_LABEL.wian, split.wian],
    [SELLER_LABEL.luan, split.luan],
    [SELLER_LABEL.dylan, split.dylan],
    ["House", split.house],
  ];
  return (
    <div className="rounded-[var(--radius-lg)] border border-border bg-elevated p-5">
      <p className="text-xs tracking-[0.16em] uppercase text-muted">
        Commission · {SELLER_LABEL[seller]} selling
      </p>
      <p className="font-display mt-2 text-3xl tabular-nums">{zar(split.profit)}</p>
      <p className="mt-1 text-xs text-subtle">Profit on the pair. Split as locked.</p>
      <ul className="mt-5 space-y-3 text-sm">
        {rows.map(([label, amount]) => (
          <li
            key={label}
            className="flex items-baseline justify-between gap-4 border-b border-border pb-2 last:border-0 last:pb-0"
          >
            <span className={amount === 0 ? "text-subtle" : ""}>{label}</span>
            <span className="tabular-nums">{zar(amount)}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
