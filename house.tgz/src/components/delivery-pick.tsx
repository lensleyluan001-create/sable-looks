import { Input, Label } from "@/components/ui/input";
import { DELIVERY_LABEL, deliveryFee, type DeliveryKind, type DeliveryRates } from "@/lib/money";
import { zar } from "@/lib/utils";

export function DeliveryPick({
  kind,
  custom,
  rates,
  onKind,
  onCustom,
}: {
  kind: DeliveryKind;
  custom: number;
  rates: DeliveryRates;
  onKind: (k: DeliveryKind) => void;
  onCustom: (n: number) => void;
}) {
  const fee = deliveryFee(kind, rates, custom);
  return (
    <div className="space-y-2">
      <Label>Delivery</Label>
      <div className="grid grid-cols-2 gap-2">
        {(["collect", "local", "international", "custom"] as const).map((k) => (
          <button
            key={k}
            type="button"
            onClick={() => onKind(k)}
            className={
              kind === k
                ? "h-11 rounded-full border border-primary bg-primary px-3 text-xs uppercase tracking-wider text-primary-foreground"
                : "h-11 rounded-full border border-border px-3 text-xs uppercase tracking-wider text-muted hover:text-fg"
            }
          >
            {DELIVERY_LABEL[k]}
          </button>
        ))}
      </div>
      {kind === "custom" ? (
        <Input
          type="number"
          min={0}
          value={custom}
          onChange={(e) => onCustom(Number(e.target.value) || 0)}
        />
      ) : (
        <p className="text-xs text-subtle">{fee ? zar(fee) : "No fee if they collect"}</p>
      )}
    </div>
  );
}
