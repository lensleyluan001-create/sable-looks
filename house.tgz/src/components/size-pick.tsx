import { Link } from "@tanstack/react-router";
import { UK_SIZES } from "@/lib/floor";
import { cn } from "@/lib/utils";

export function SizePick({
  value,
  onChange,
}: {
  value: string;
  onChange: (size: string) => void;
}) {
  return (
    <div>
      <div className="flex items-baseline justify-between gap-3">
        <p className="text-xs tracking-[0.16em] uppercase text-muted">UK size</p>
        <Link
          to="/sizes"
          className="text-xs tracking-[0.12em] uppercase text-muted hover:text-fg"
        >
          Size guide
        </Link>
      </div>
      <div className="mt-3 flex flex-wrap gap-2">
        {UK_SIZES.map((s) => {
          const on = value === s;
          return (
            <button
              key={s}
              type="button"
              onClick={() => onChange(on ? "" : s)}
              className={cn(
                "grid h-11 min-w-11 place-items-center rounded-[var(--radius-sm)] border text-sm tabular-nums",
                on
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-border text-muted hover:text-fg",
              )}
            >
              {s}
            </button>
          );
        })}
      </div>
    </div>
  );
}
