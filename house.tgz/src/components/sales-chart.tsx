import { useMemo } from "react";
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import type { Invoice } from "@/lib/floor";
import { invoiceTotal } from "@/lib/money";
import { zar } from "@/lib/utils";

function dayKey(iso: string) {
  const d = new Date(iso);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function labelDay(key: string) {
  const [y, m, d] = key.split("-").map(Number);
  const dt = new Date(y, m - 1, d);
  return dt.toLocaleDateString("en-ZA", { day: "numeric", month: "short" });
}

export function SalesChart({ invoices }: { invoices: Invoice[] }) {
  const data = useMemo(() => {
    const days: { key: string; total: number; paid: number }[] = [];
    const now = new Date();
    for (let i = 13; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() - i);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
      days.push({ key, total: 0, paid: 0 });
    }
    const map = new Map(days.map((x) => [x.key, x]));
    for (const inv of invoices) {
      const row = map.get(dayKey(inv.at));
      if (!row) continue;
      const amt = invoiceTotal(inv.unitPrice, inv.qty, inv.deliveryFee);
      row.total += amt;
      if (inv.status === "paid") row.paid += amt;
    }
    return days.map((d) => ({ ...d, label: labelDay(d.key) }));
  }, [invoices]);

  const has = data.some((d) => d.total > 0);

  if (!has) {
    return (
      <div className="flex h-48 items-center justify-center rounded-[var(--radius-lg)] border border-border bg-elevated px-4 text-center">
        <p className="max-w-sm text-sm text-muted">
          Raise an invoice from a lead. Paid totals draw the line.
        </p>
      </div>
    );
  }

  return (
    <div className="h-48 w-full rounded-[var(--radius-lg)] border border-border bg-elevated px-2 py-3 sm:h-56">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
          <XAxis
            dataKey="label"
            tick={{ fill: "currentColor", fontSize: 10 }}
            axisLine={false}
            tickLine={false}
            interval={2}
          />
          <YAxis
            tick={{ fill: "currentColor", fontSize: 10 }}
            axisLine={false}
            tickLine={false}
            width={44}
            tickFormatter={(v: number) => (v >= 1000 ? `${Math.round(v / 1000)}k` : `${v}`)}
          />
          <Tooltip
            contentStyle={{
              background: "var(--color-elevated)",
              border: "1px solid var(--color-border)",
              borderRadius: 8,
              color: "var(--color-fg)",
              fontSize: 12,
            }}
            formatter={(v) => zar(Number(v))}
          />
          <Area
            type="monotone"
            dataKey="total"
            stroke="var(--color-primary)"
            fill="var(--color-primary)"
            fillOpacity={0.18}
            strokeWidth={2}
            name="Invoiced"
          />
          <Area
            type="monotone"
            dataKey="paid"
            stroke="var(--color-fg)"
            fill="transparent"
            strokeWidth={1.5}
            name="Paid"
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
