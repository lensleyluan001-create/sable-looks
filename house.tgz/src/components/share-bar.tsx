import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { waHref } from "@/lib/floor";
import { useSable } from "@/lib/store";
import { cn } from "@/lib/utils";

export function ShareBar({ path = "/", compact = false }: { path?: string; compact?: boolean }) {
  const shareLine = useSable((s) => s.copy.shareLine);
  const [copied, setCopied] = useState(false);
  const [url, setUrl] = useState("");

  useEffect(() => {
    setUrl(`${window.location.origin}${path}`);
  }, [path]);

  const text = url ? `${shareLine}\n${url}` : shareLine;
  const wa = url ? waHref("", text) : "#";
  const x = url
    ? `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareLine)}&url=${encodeURIComponent(url)}`
    : "#";

  async function copy() {
    await navigator.clipboard.writeText(text);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1600);
  }

  async function nativeShare() {
    if (navigator.share && url) {
      try {
        await navigator.share({ title: "SABLE.CO", text: shareLine, url });
        return;
      } catch {
        /* cancelled */
      }
    }
    await copy();
  }

  return (
    <div className={cn("grid grid-cols-2 gap-2 sm:flex sm:flex-wrap", compact ? "sm:gap-2" : "sm:gap-3")}>
      <Button type="button" className="w-full sm:w-auto" onClick={() => void nativeShare()}>
        Share
      </Button>
      <Button type="button" variant="outline" className="w-full sm:w-auto" onClick={() => void copy()}>
        {copied ? "Copied" : "Copy link"}
      </Button>
      <Button asChild variant="outline" className="w-full sm:w-auto">
        <a href={wa} target="_blank" rel="noreferrer">
          WhatsApp
        </a>
      </Button>
      <Button asChild variant="outline" className="w-full sm:w-auto">
        <a href={x} target="_blank" rel="noreferrer">
          Post on X
        </a>
      </Button>
    </div>
  );
}
