import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";

export function DeskGate({ need }: { need: "manager" | "admin" }) {
  return (
    <main className="mx-auto max-w-lg px-4 py-20 text-center sm:px-6">
      <p className="text-xs tracking-[0.22em] uppercase text-muted">Restricted</p>
      <h1 className="font-display mt-3 text-4xl">Manager desk</h1>
      <p className="mt-4 text-sm text-muted">
        This file is not on the sales desk. A {need} code opens the full house.
      </p>
      <Button asChild className="mt-8">
        <Link to="/desk">Open desk</Link>
      </Button>
    </main>
  );
}

export function GatePending() {
  return (
    <main className="mx-auto max-w-lg px-4 py-20 text-center sm:px-6">
      <p className="text-xs tracking-[0.22em] uppercase text-muted">House</p>
      <h1 className="font-display mt-3 text-4xl">Opening…</h1>
    </main>
  );
}
