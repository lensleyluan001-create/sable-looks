create table if not exists house_orders (
  id text primary key,
  sku text not null,
  look text not null,
  size text not null,
  qty integer not null default 1,
  name text not null,
  phone text not null,
  address text not null default '',
  note text not null default '',
  delivery text not null default 'collect',
  delivery_fee integer not null default 0,
  unit_price integer not null,
  assigned_to text,
  assigned_by text,
  assigned_at timestamptz,
  status text not null default 'new',
  created_at timestamptz not null default now()
);

create index if not exists house_orders_created_idx on house_orders (created_at desc);
create index if not exists house_orders_assigned_idx on house_orders (assigned_to);

create table if not exists house_meta (
  key text primary key,
  value text not null
);

insert into house_meta (key, value)
values ('last_seller', 'dylan')
on conflict (key) do nothing;
